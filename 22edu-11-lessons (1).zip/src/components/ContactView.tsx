import React, { useState } from 'react';
import { FAQS } from '../data/booksData';

export const ContactView: React.FC<{ onOpenEtsy: () => void }> = ({ onOpenEtsy }) => {
  const [formData, setFormData] = useState({
    name: 'Pavithra Prasanna',
    email: 'pavithraprasanna21@gmail.com',
    category: 'Digital Download Support',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.message) {
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setFormData({ ...formData, message: '' });
      }, 7000);
    }
  };

  return (
    <div className="py-10 max-w-[1200px] mx-auto px-5 lg:px-10 space-y-12">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#eaedff] text-xs font-bold text-[#855300] uppercase tracking-wider">
          Reader Care &amp; Inquiries
        </div>
        <h1 className="font-headline text-3xl sm:text-4xl text-[#000f3f] font-bold tracking-tight">
          Contact &amp; eBook Support
        </h1>
        <p className="text-sm sm:text-base text-[#45464f] max-w-2xl leading-relaxed">
          Need help loading files onto your Kindle, curious about classroom licensing, or have an
          author inquiry? Our publishing team typically responds within 12 business hours.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-[#eaedff] shadow-sm space-y-6">
          <div className="space-y-1">
            <h2 className="font-headline text-xl font-bold text-[#000f3f]">
              Send Us a Direct Message
            </h2>
            <p className="text-xs sm:text-sm text-[#45464f]">
              Fill out the details below and we will get back to you promptly.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="font-bold text-[#000f3f]">Your Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Full name"
                  className="w-full bg-[#faf8ff] px-3.5 py-2.5 rounded-xl border border-[#c6c5d0] focus:ring-2 focus:ring-[#172554]/20 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-[#000f3f]">Your Email Address</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="you@domain.com"
                  className="w-full bg-[#faf8ff] px-3.5 py-2.5 rounded-xl border border-[#c6c5d0] focus:ring-2 focus:ring-[#172554]/20 focus:outline-none"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-[#000f3f]">Topic / Inquiry Type</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full bg-[#faf8ff] px-3.5 py-2.5 rounded-xl border border-[#c6c5d0] focus:ring-2 focus:ring-[#172554]/20 focus:outline-none"
              >
                <option value="Digital Download Support">Etsy Digital Download Assistance</option>
                <option value="Device Compatibility">Device / Kindle / ePub Compatibility</option>
                <option value="Book Suggestion">New Topic or Guide Suggestion</option>
                <option value="Author Collaboration">Author / Curriculum Collaboration</option>
                <option value="General Inquiry">General Question</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-[#000f3f]">Your Message</label>
              <textarea
                required
                rows={4}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="How can we assist you with Edu 11 Lessons today? (e.g. order help, format question...)"
                className="w-full bg-[#faf8ff] p-3.5 rounded-xl border border-[#c6c5d0] focus:ring-2 focus:ring-[#172554]/20 focus:outline-none resize-y"
              ></textarea>
            </div>

            {submitted && (
              <div className="p-4 bg-[#e2e7ff] text-[#000f3f] rounded-xl flex items-center gap-2 border border-[#808dc2]/40 text-xs font-semibold animate-in fade-in">
                <span className="material-symbols-outlined text-[18px] text-[#855300]">check_circle</span>
                <span>
                  Thank you, {formData.name}! Your message has been dispatched to our support team.
                </span>
              </div>
            )}

            <button
              type="submit"
              className="w-full sm:w-auto px-7 py-3 rounded-xl bg-[#000f3f] text-white hover:bg-[#172554] font-bold shadow transition-all active:scale-95"
            >
              Send Message
            </button>
          </form>
        </div>

        {/* Support Highlights Box */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#eaedff] p-6 rounded-2xl border border-[#c6c5d0]/40 space-y-4">
            <div className="flex items-center gap-3">
              <span className="w-10 h-10 rounded-xl bg-white text-[#855300] flex items-center justify-center shadow-xs">
                <span className="material-symbols-outlined text-[24px]">support_agent</span>
              </span>
              <div>
                <h3 className="font-headline text-base font-bold text-[#000f3f]">
                  Etsy Dedicated Support
                </h3>
                <p className="text-xs text-[#45464f]">Fast assistance for buyers</p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              If you purchased via our official Etsy storefront and need an updated download link,
              you can contact us directly through Etsy conversations for instant order matching.
            </p>

            <button
              onClick={onOpenEtsy}
              className="w-full py-2.5 px-4 rounded-xl bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] font-bold text-xs shadow-sm flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[16px]">storefront</span>
              <span>Visit Official Etsy Storefront</span>
              <span className="material-symbols-outlined text-[14px]">open_in_new</span>
            </button>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#eaedff] shadow-sm space-y-3 text-xs sm:text-sm">
            <h4 className="font-headline font-bold text-[#000f3f]">Direct Email Support</h4>
            <p className="text-[#45464f]">
              Publishing Desk:{' '}
              <span className="font-mono text-[#000f3f] font-semibold">
                hello@edu11lessons.com
              </span>
            </p>
            <p className="text-[#45464f]">
              Response Window:{' '}
              <span className="text-[#131b2e] font-medium">Monday–Saturday, 9am–6pm EST</span>
            </p>
          </div>
        </div>
      </div>

      {/* eBook FAQ Section */}
      <div className="bg-white p-6 sm:p-10 rounded-2xl border border-[#eaedff] shadow-sm space-y-6">
        <div className="space-y-1">
          <span className="text-xs text-[#855300] font-bold uppercase tracking-wider">
            Clear Answers
          </span>
          <h2 className="font-headline text-2xl sm:text-3xl text-[#000f3f] font-bold">
            Frequently Asked Questions
          </h2>
          <p className="text-xs sm:text-sm text-[#45464f]">
            Everything you need to know about digital delivery, device compatibility, and file access.
          </p>
        </div>

        <div className="space-y-3 pt-2">
          {FAQS.map((faq, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={idx}
                className="border border-[#eaedff] rounded-xl overflow-hidden bg-[#faf8ff] transition-all"
              >
                <button
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  className="w-full p-4 text-left flex items-center justify-between hover:bg-[#eaedff]/60 transition-colors"
                >
                  <span className="font-headline text-sm sm:text-base font-bold text-[#000f3f] pr-4">
                    {faq.question}
                  </span>
                  <span className="material-symbols-outlined text-[#767680] text-[20px] shrink-0">
                    {isOpen ? 'expand_less' : 'expand_more'}
                  </span>
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 pt-1 bg-white border-t border-[#eaedff] text-xs sm:text-sm text-[#45464f] leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
