import React from 'react';
import { APP_ASSETS } from '../data/booksData';
import { CategoryId } from '../types/book';

interface FooterProps {
  onNavigate: (view: string) => void;
  onSelectCategory: (cat: CategoryId) => void;
  onOpenEtsy: () => void;
  onOpenLegal: (topic: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onSelectCategory,
  onOpenEtsy,
  onOpenLegal,
}) => {
  return (
    <footer className="w-full bg-[#f2f3ff] text-[#131b2e] pt-12 sm:pt-16 pb-8 border-t border-[#eaedff]">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12">
          {/* Col 1: Brand & Etsy link */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <img
                alt="Edu 11 Lessons Logo"
                className="h-8 w-auto object-contain"
                src={APP_ASSETS.logo}
              />
              <span className="font-headline text-xl text-[#000f3f] tracking-tight font-bold">
                Edu 11 Lessons
              </span>
            </div>

            <p className="text-xs sm:text-sm text-[#45464f] max-w-sm leading-relaxed">
              Learning Made Simple: Practical digital books and inspiring resources to help you
              learn more, create more, and achieve more.
            </p>

            <div className="pt-1">
              <button
                onClick={onOpenEtsy}
                className="inline-flex items-center gap-2 text-xs font-semibold bg-white text-[#131b2e] hover:bg-[#eaedff] transition-colors px-4 py-2.5 rounded-lg shadow-sm border border-[#c6c5d0]/50"
              >
                <span className="material-symbols-outlined text-[18px] text-[#855300]">storefront</span>
                <span>Official Etsy Storefront</span>
                <span className="material-symbols-outlined text-[14px] text-[#767680]">open_in_new</span>
              </button>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold text-[#000f3f] uppercase tracking-wider">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#45464f]">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('all-books')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  All Books
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('categories')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Categories
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about-us')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Book Categories */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-[#000f3f] uppercase tracking-wider">
              Book Categories
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#45464f]">
              <li>
                <button
                  onClick={() => onSelectCategory('cookbooks')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Cookbooks &amp; Recipes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('education')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Education &amp; Study Guides
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('tech')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Tech &amp; Digital Skills
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('language')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Language Learning
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('creative')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Creative Guides
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('lifestyle')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Lifestyle &amp; Hobbies
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Legal & Support */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold text-[#000f3f] uppercase tracking-wider">
              Legal &amp; Support
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#45464f]">
              <li>
                <button
                  onClick={() => onOpenLegal('privacy')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenLegal('terms')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Terms &amp; Conditions
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenLegal('refund')}
                  className="hover:text-[#000f3f] transition-colors text-left"
                >
                  Refund Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#000f3f] transition-colors text-left font-medium text-[#855300]"
                >
                  eBook Delivery FAQ
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4 bg-[#eaedff]/60 px-5 py-4 rounded-xl border border-[#c6c5d0]/30 text-xs text-[#45464f]">
          <p className="text-center md:text-left">
            © 2026 Edu 11 Lessons. All rights reserved.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 font-medium">
            <span className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#855300]">verified</span>
              <span>Instant Digital PDF/ePub Delivery</span>
            </span>
            <span className="hidden sm:inline text-gray-300">•</span>
            <span className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#855300]">lock</span>
              <span>Secured via Etsy Payments</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
