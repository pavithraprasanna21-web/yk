import React, { useState } from 'react';
import { Book } from '../types/book';

interface BookDetailModalProps {
  book: Book | null;
  onClose: () => void;
  onBuy: (book: Book) => void;
  isSaved: boolean;
  onToggleSave: (bookId: string) => void;
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({
  book,
  onClose,
  onBuy,
  isSaved,
  onToggleSave,
}) => {
  const [activeTab, setActiveTab] = useState<'syllabus' | 'sample' | 'specs'>('syllabus');
  const [expandedLesson, setExpandedLesson] = useState<number | null>(1);
  const [readerFontSize, setReaderFontSize] = useState<'sm' | 'base' | 'lg'>('base');
  const [paperTheme, setPaperTheme] = useState<'clean' | 'warm' | 'dark'>('clean');
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!book) return null;

  const handleDownloadSample = () => {
    setDownloadSuccess(true);
    // Create a simple downloadable text/markdown file sample
    const sampleContent = `${book.title}\nBy ${book.author}\nPublished by Edu 11 Lessons\n\n${book.sampleChapterText || book.description}\n\nVisit Edu 11 Lessons on Etsy for full access.`;
    const blob = new Blob([sampleContent], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${book.id}-sample-lesson1.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setTimeout(() => setDownloadSuccess(false), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#000f3f]/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div
        className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden border border-[#eaedff] flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        role="dialog"
      >
        {/* Modal Top Bar */}
        <div className="px-5 py-4 bg-[#f2f3ff] border-b border-[#eaedff] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#855300] uppercase tracking-wider">
              {book.categoryLabel}
            </span>
            <span className="text-gray-300">•</span>
            <span className="text-xs text-[#45464f] font-medium">11 Curated Lessons</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleSave(book.id)}
              className="p-1.5 rounded-lg text-[#767680] hover:text-[#855300] hover:bg-[#eaedff] transition-colors"
              title={isSaved ? 'Saved to library' : 'Save for later'}
            >
              <span
                className={`material-symbols-outlined text-[20px] ${
                  isSaved ? 'text-[#855300] fill-1' : ''
                }`}
              >
                {isSaved ? 'bookmark' : 'bookmark_border'}
              </span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#767680] hover:text-[#000f3f] hover:bg-[#eaedff] transition-colors"
              title="Close modal"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* Modal Content Scroll Area */}
        <div className="overflow-y-auto p-5 sm:p-7 space-y-6">
          {/* Top Overview Split */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            {/* Book Cover */}
            <div className="md:col-span-4 flex flex-col items-center">
              <div className="relative bg-[#eaedff] p-3 rounded-xl shadow-md border border-[#c6c5d0]/40 max-w-[240px] w-full">
                <img
                  src={book.coverImage}
                  alt={book.altText}
                  className="w-full h-auto rounded-lg object-contain aspect-[3/4] shadow"
                />
                {book.tag && (
                  <span className="absolute top-5 right-5 px-2.5 py-0.5 rounded-full bg-[#ffddb8] text-[#855300] text-[10px] font-bold shadow">
                    {book.tag}
                  </span>
                )}
              </div>

              {/* Price & Primary Buy */}
              <div className="mt-4 w-full max-w-[240px] space-y-2">
                <button
                  onClick={() => onBuy(book)}
                  className="w-full py-3 px-4 rounded-xl bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <span className="material-symbols-outlined text-[18px]">shopping_bag</span>
                  <span>Buy on Etsy · ${book.price.toFixed(2)}</span>
                </button>

                <button
                  onClick={handleDownloadSample}
                  className="w-full py-2.5 px-3 rounded-xl bg-[#f2f3ff] text-[#000f3f] hover:bg-[#eaedff] font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 border border-[#c6c5d0]/50"
                >
                  <span className="material-symbols-outlined text-[16px]">download</span>
                  <span>Free Sample (Lesson 1)</span>
                </button>

                {downloadSuccess && (
                  <p className="text-[11px] text-center text-emerald-700 font-medium">
                    ✓ Sample markdown file downloaded!
                  </p>
                )}
              </div>
            </div>

            {/* Book Metadata & Description */}
            <div className="md:col-span-8 space-y-4">
              <div>
                <h2 className="font-headline text-2xl sm:text-3xl text-[#000f3f] font-bold leading-tight">
                  {book.title}
                </h2>
                <p className="text-xs sm:text-sm text-[#45464f] mt-1">
                  By <span className="font-semibold text-[#131b2e]">{book.author}</span> · Published by Edu 11 Lessons
                </p>
              </div>

              {/* Star ratings */}
              <div className="flex items-center gap-1.5 text-[#855300]">
                {[1, 2, 3, 4, 5].map((s) => (
                  <span key={s} className="material-symbols-outlined text-[18px] fill-1">
                    star
                  </span>
                ))}
                <span className="text-xs font-bold text-[#131b2e] ml-1">
                  {book.rating.toFixed(2)}
                </span>
                <span className="text-xs text-[#45464f]">
                  ({book.reviewCount} verified reader reviews)
                </span>
              </div>

              {/* Narrative description */}
              <p className="text-sm text-[#45464f] leading-relaxed">
                {book.fullDescription || book.description}
              </p>

              {/* Badges strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                <div className="bg-[#f2f3ff] p-2.5 rounded-lg text-center border border-[#eaedff]">
                  <p className="text-[10px] text-[#45464f] uppercase font-bold">Structure</p>
                  <p className="text-xs font-bold text-[#000f3f] mt-0.5">11 Master Lessons</p>
                </div>
                <div className="bg-[#f2f3ff] p-2.5 rounded-lg text-center border border-[#eaedff]">
                  <p className="text-[10px] text-[#45464f] uppercase font-bold">Formats</p>
                  <p className="text-xs font-bold text-[#000f3f] mt-0.5">PDF + ePub</p>
                </div>
                <div className="bg-[#f2f3ff] p-2.5 rounded-lg text-center border border-[#eaedff]">
                  <p className="text-[10px] text-[#45464f] uppercase font-bold">Total Pages</p>
                  <p className="text-xs font-bold text-[#000f3f] mt-0.5">{book.pageCount} Pages</p>
                </div>
                <div className="bg-[#f2f3ff] p-2.5 rounded-lg text-center border border-[#eaedff]">
                  <p className="text-[10px] text-[#45464f] uppercase font-bold">Delivery</p>
                  <p className="text-xs font-bold text-[#855300] mt-0.5">Instant Digital</p>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-[#eaedff] flex items-center gap-2 pt-2">
            <button
              onClick={() => setActiveTab('syllabus')}
              className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
                activeTab === 'syllabus'
                  ? 'border-[#000f3f] text-[#000f3f]'
                  : 'border-transparent text-[#45464f] hover:text-[#131b2e]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">list_alt</span>
              <span>11-Lesson Curriculum ({book.lessons?.length || 11})</span>
            </button>

            <button
              onClick={() => setActiveTab('sample')}
              className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
                activeTab === 'sample'
                  ? 'border-[#000f3f] text-[#000f3f]'
                  : 'border-transparent text-[#45464f] hover:text-[#131b2e]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">menu_book</span>
              <span>Look Inside Sample Reader</span>
            </button>

            <button
              onClick={() => setActiveTab('specs')}
              className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
                activeTab === 'specs'
                  ? 'border-[#000f3f] text-[#000f3f]'
                  : 'border-transparent text-[#45464f] hover:text-[#131b2e]'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">devices</span>
              <span>File Specs &amp; Delivery</span>
            </button>
          </div>

          {/* Tab 1: 11-Lesson Curriculum Accordion */}
          {activeTab === 'syllabus' && (
            <div className="space-y-2.5 animate-in fade-in duration-150">
              <p className="text-xs text-[#45464f] mb-3">
                Every chapter is sequentially calibrated to eliminate filler and bring you to actionable mastery.
              </p>

              {(book.lessons && book.lessons.length > 0
                ? book.lessons
                : Array.from({ length: 11 }).map((_, i) => ({
                    number: i + 1,
                    title: `Curated Lesson ${i + 1}: Foundational Framework`,
                    duration: '45 mins',
                    summary: 'Structured practical walkthrough with concrete exercises and reference materials.',
                    keyTakeaway: 'Concrete skill application ready for immediate execution.',
                  }))
              ).map((lesson) => {
                const isOpen = expandedLesson === lesson.number;
                return (
                  <div
                    key={lesson.number}
                    className="border border-[#eaedff] rounded-xl overflow-hidden bg-[#faf8ff] transition-all"
                  >
                    <button
                      onClick={() => setExpandedLesson(isOpen ? null : lesson.number)}
                      className="w-full p-3.5 sm:p-4 text-left flex items-center justify-between hover:bg-[#eaedff]/60 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-7 h-7 rounded-full bg-[#172554] text-white text-xs font-bold flex items-center justify-center shrink-0">
                          {lesson.number}
                        </span>
                        <div>
                          <h4 className="font-headline text-sm sm:text-base font-bold text-[#000f3f]">
                            {lesson.title}
                          </h4>
                          <span className="text-[11px] text-[#45464f]">
                            Est. Study Time: {lesson.duration}
                          </span>
                        </div>
                      </div>

                      <span className="material-symbols-outlined text-[#767680] text-[20px]">
                        {isOpen ? 'expand_less' : 'expand_more'}
                      </span>
                    </button>

                    {isOpen && (
                      <div className="px-4 pb-4 pt-1 bg-white border-t border-[#eaedff] text-xs sm:text-sm space-y-2">
                        <p className="text-[#45464f]">{lesson.summary}</p>
                        <div className="p-2.5 rounded-lg bg-[#f2f3ff] text-[#000f3f] flex items-start gap-2 border border-[#c6c5d0]/30">
                          <span className="material-symbols-outlined text-[16px] text-[#855300] shrink-0 mt-0.5">
                            lightbulb
                          </span>
                          <div>
                            <span className="font-bold">Core Learning Takeaway: </span>
                            <span>{lesson.keyTakeaway}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Tab 2: Sample Reader */}
          {activeTab === 'sample' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Reader Controls Bar */}
              <div className="p-3 bg-[#f2f3ff] rounded-xl flex flex-wrap items-center justify-between gap-3 border border-[#eaedff]">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#45464f]">Font Size:</span>
                  {(['sm', 'base', 'lg'] as const).map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setReaderFontSize(sz)}
                      className={`px-2.5 py-1 text-xs rounded font-bold uppercase ${
                        readerFontSize === sz
                          ? 'bg-[#000f3f] text-white'
                          : 'bg-white text-[#45464f] hover:bg-[#eaedff]'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-[#45464f]">Theme:</span>
                  <button
                    onClick={() => setPaperTheme('clean')}
                    className={`px-2.5 py-1 text-xs rounded font-medium ${
                      paperTheme === 'clean' ? 'ring-2 ring-[#000f3f]' : ''
                    } bg-white text-gray-900 border`}
                  >
                    Clean White
                  </button>
                  <button
                    onClick={() => setPaperTheme('warm')}
                    className={`px-2.5 py-1 text-xs rounded font-medium ${
                      paperTheme === 'warm' ? 'ring-2 ring-[#855300]' : ''
                    } bg-[#fbf0d9] text-[#4a341b] border border-amber-200`}
                  >
                    Warm Paper
                  </button>
                  <button
                    onClick={() => setPaperTheme('dark')}
                    className={`px-2.5 py-1 text-xs rounded font-medium ${
                      paperTheme === 'dark' ? 'ring-2 ring-blue-400' : ''
                    } bg-[#131b2e] text-slate-100 border border-slate-700`}
                  >
                    Midnight
                  </button>
                </div>
              </div>

              {/* Reader Surface */}
              <div
                className={`p-6 sm:p-8 rounded-xl shadow-inner border max-h-[380px] overflow-y-auto leading-relaxed transition-colors ${
                  paperTheme === 'clean'
                    ? 'bg-white text-slate-900 border-slate-200'
                    : paperTheme === 'warm'
                    ? 'bg-[#fbf0d9] text-[#332211] border-amber-200'
                    : 'bg-[#131b2e] text-slate-100 border-slate-800'
                } ${
                  readerFontSize === 'sm'
                    ? 'text-xs sm:text-sm'
                    : readerFontSize === 'lg'
                    ? 'text-base sm:text-lg'
                    : 'text-sm sm:text-base'
                }`}
              >
                <div className="max-w-2xl mx-auto space-y-4">
                  <div className="border-b pb-3 mb-4 opacity-70 flex items-center justify-between text-xs">
                    <span>Sample Chapter Preview · Lesson 1</span>
                    <span>Edu 11 Lessons</span>
                  </div>

                  <div className="whitespace-pre-line font-serif leading-relaxed">
                    {book.sampleChapterText || (
                      `# Lesson 1: Foundational Core Principles\n\nWelcome to your 11-lesson curriculum.\n\nEvery principle in this manual has been vetted through dozens of real-world trials to eliminate superfluous academic padding. As you begin your journey through this series, remember that retention is built through immediate application.\n\n### The Direct Path to Competence\n1. Review the conceptual framework\n2. Complete the diagnostic checklist\n3. Implement the practical exercise within 24 hours\n\nWhen you complete all 11 chapters, you will possess enduring mastery.`
                    )}
                  </div>

                  <div className="pt-6 border-t mt-6 text-center space-y-2 opacity-90">
                    <p className="text-xs italic">
                      End of Sample Excerpt. The complete book contains 10 additional lessons, checklists, and printable companion assets.
                    </p>
                    <button
                      onClick={() => onBuy(book)}
                      className="px-5 py-2.5 rounded-lg bg-[#fea619] text-[#684000] font-bold text-xs shadow hover:bg-[#ffb95f]"
                    >
                      Unlock All 11 Lessons on Etsy (${book.price.toFixed(2)})
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: File Specs & Delivery */}
          {activeTab === 'specs' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#faf8ff] border border-[#eaedff] space-y-2">
                  <div className="flex items-center gap-2 text-[#000f3f] font-bold text-sm">
                    <span className="material-symbols-outlined text-[20px] text-[#855300]">picture_as_pdf</span>
                    <span>High-Resolution PDF</span>
                  </div>
                  <p className="text-xs text-[#45464f] leading-relaxed">
                    Rendered at 300 DPI with vector typography. Perfect for GoodNotes, Notability, Adobe Acrobat, and wide desktop screens. Features interactive hyperlinked table of contents.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#faf8ff] border border-[#eaedff] space-y-2">
                  <div className="flex items-center gap-2 text-[#000f3f] font-bold text-sm">
                    <span className="material-symbols-outlined text-[20px] text-[#855300]">book</span>
                    <span>Reflowable ePub Format</span>
                  </div>
                  <p className="text-xs text-[#45464f] leading-relaxed">
                    Engineered for Kindle (via Send to Kindle), Apple Books, Kobo, and Boox e-ink devices. Adjust font family, line spacing, and margin widths to your personal comfort.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#faf8ff] border border-[#eaedff] space-y-2">
                  <div className="flex items-center gap-2 text-[#000f3f] font-bold text-sm">
                    <span className="material-symbols-outlined text-[20px] text-[#855300]">folder_zip</span>
                    <span>Companion Digital Files</span>
                  </div>
                  <p className="text-xs text-[#45464f] leading-relaxed">
                    Packaged ZIP bundle including printable workout sheets, source code notebooks, and supplementary reference charts.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#faf8ff] border border-[#eaedff] space-y-2">
                  <div className="flex items-center gap-2 text-[#000f3f] font-bold text-sm">
                    <span className="material-symbols-outlined text-[20px] text-[#855300]">lock</span>
                    <span>DRM-Free Lifetime Access</span>
                  </div>
                  <p className="text-xs text-[#45464f] leading-relaxed">
                    No restrictive proprietary locks. You own the files forever and can store them on your personal backup drives or cloud storage.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Bar */}
        <div className="px-5 py-4 bg-[#f2f3ff] border-t border-[#eaedff] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-[#45464f]">
            <span className="material-symbols-outlined text-[16px] text-emerald-600">verified</span>
            <span>Fulfilled instantly upon purchase via Etsy download vault</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-[#45464f] hover:bg-[#eaedff] transition-colors"
            >
              Close
            </button>
            <button
              onClick={() => onBuy(book)}
              className="px-5 py-2.5 rounded-lg bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] text-xs font-bold shadow transition-all flex items-center gap-1.5"
            >
              <span>Buy on Etsy · ${book.price.toFixed(2)}</span>
              <span className="material-symbols-outlined text-[15px]">open_in_new</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
