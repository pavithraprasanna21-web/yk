import React, { useState } from 'react';
import { APP_ASSETS } from '../data/booksData';
import { Book } from '../types/book';

interface ProfileModalProps {
  onClose: () => void;
  savedBooks: Book[];
  purchasedBooks: Book[];
  onOpenBook: (bookId: string) => void;
  onRemoveSaved: (bookId: string) => void;
  onOpenEtsyCheckout: (book: Book) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  onClose,
  savedBooks,
  purchasedBooks,
  onOpenBook,
  onRemoveSaved,
  onOpenEtsyCheckout,
}) => {
  const [activeTab, setActiveTab] = useState<'purchased' | 'saved'>('purchased');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#000f3f]/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden border border-[#eaedff] flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="p-6 bg-[#f2f3ff] border-b border-[#eaedff] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img
              src={APP_ASSETS.profileAvatar}
              alt="User Profile"
              className="w-14 h-14 rounded-full object-cover border-2 border-[#fea619] shadow"
            />
            <div>
              <h3 className="font-headline text-lg font-bold text-[#000f3f]">
                Pavithra Prasanna
              </h3>
              <p className="text-xs text-[#45464f] font-mono">pavithraprasanna21@gmail.com</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] bg-[#ffddb8] text-[#855300] font-bold px-2 py-0.5 rounded-full">
                  ★ Verified Etsy Member
                </span>
                <span className="text-[10px] bg-[#dce1ff] text-[#071747] font-semibold px-2 py-0.5 rounded-full">
                  E-Reader Synced
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#767680] hover:text-[#000f3f] hover:bg-[#eaedff] transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-3 divide-x border-b border-[#eaedff] bg-white text-center py-3 text-xs">
          <div>
            <p className="font-headline text-lg font-bold text-[#000f3f]">
              {purchasedBooks.length}
            </p>
            <p className="text-[11px] text-[#45464f]">Books Owned</p>
          </div>
          <div>
            <p className="font-headline text-lg font-bold text-[#855300]">
              {savedBooks.length}
            </p>
            <p className="text-[11px] text-[#45464f]">Saved for Later</p>
          </div>
          <div>
            <p className="font-headline text-lg font-bold text-[#172554]">
              {purchasedBooks.length * 11 || 11}
            </p>
            <p className="text-[11px] text-[#45464f]">Available Lessons</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="px-6 border-b border-[#eaedff] flex items-center gap-4 bg-[#faf8ff]">
          <button
            onClick={() => setActiveTab('purchased')}
            className={`py-3 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'purchased'
                ? 'border-[#000f3f] text-[#000f3f]'
                : 'border-transparent text-[#45464f] hover:text-[#131b2e]'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">menu_book</span>
            <span>My Digital Library ({purchasedBooks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('saved')}
            className={`py-3 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'saved'
                ? 'border-[#000f3f] text-[#000f3f]'
                : 'border-transparent text-[#45464f] hover:text-[#131b2e]'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">bookmark</span>
            <span>Saved Wishlist ({savedBooks.length})</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto space-y-3 flex-1 min-h-[220px]">
          {activeTab === 'purchased' && (
            <>
              {purchasedBooks.length > 0 ? (
                purchasedBooks.map((book) => (
                  <div
                    key={book.id}
                    className="p-3.5 rounded-xl border border-[#eaedff] bg-[#faf8ff] flex items-center justify-between gap-4 hover:bg-[#f2f3ff] transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={book.coverImage}
                        alt={book.altText}
                        className="w-12 h-16 object-contain rounded bg-white shadow-xs p-0.5 shrink-0"
                      />
                      <div className="min-w-0">
                        <span className="text-[10px] uppercase font-bold text-[#855300]">
                          {book.categoryLabel}
                        </span>
                        <h4 className="font-headline text-sm font-bold text-[#000f3f] truncate">
                          {book.title}
                        </h4>
                        <p className="text-[11px] text-[#45464f]">11 Lessons · PDF + ePub Ready</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          onOpenBook(book.id);
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-[#000f3f] text-white rounded-lg text-xs font-semibold hover:bg-[#172554]"
                      >
                        Read
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 space-y-2">
                  <span className="material-symbols-outlined text-4xl text-[#767680]">
                    library_books
                  </span>
                  <p className="font-headline text-sm font-bold text-[#000f3f]">
                    No purchased publications yet
                  </p>
                  <p className="text-xs text-[#45464f]">
                    When you order on Etsy, your books sync automatically here.
                  </p>
                </div>
              )}
            </>
          )}

          {activeTab === 'saved' && (
            <>
              {savedBooks.length > 0 ? (
                savedBooks.map((book) => (
                  <div
                    key={book.id}
                    className="p-3.5 rounded-xl border border-[#eaedff] bg-[#faf8ff] flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={book.coverImage}
                        alt={book.altText}
                        className="w-12 h-16 object-contain rounded bg-white shadow-xs p-0.5 shrink-0"
                      />
                      <div className="min-w-0">
                        <span className="text-[10px] uppercase font-bold text-[#855300]">
                          {book.categoryLabel}
                        </span>
                        <h4 className="font-headline text-sm font-bold text-[#000f3f] truncate">
                          {book.title}
                        </h4>
                        <p className="text-[11px] text-[#45464f]">${book.price.toFixed(2)} USD</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          onOpenEtsyCheckout(book);
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-[#fea619] text-[#684000] rounded-lg text-xs font-bold hover:bg-[#ffb95f]"
                      >
                        Checkout
                      </button>
                      <button
                        onClick={() => onRemoveSaved(book.id)}
                        className="p-1.5 text-[#767680] hover:text-red-600"
                        title="Remove from saved"
                      >
                        <span className="material-symbols-outlined text-[18px]">delete</span>
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 space-y-2">
                  <span className="material-symbols-outlined text-4xl text-[#767680]">
                    bookmark_border
                  </span>
                  <p className="font-headline text-sm font-bold text-[#000f3f]">
                    Your reading wishlist is empty
                  </p>
                  <p className="text-xs text-[#45464f]">
                    Tap the bookmark icon on any book card to save it for quick reference.
                  </p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f2f3ff] border-t border-[#eaedff] flex justify-between items-center text-xs text-[#45464f]">
          <span>Etsy Shop: @Edu11Lessons</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white text-[#000f3f] border border-[#c6c5d0] rounded-lg font-semibold hover:bg-[#eaedff]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
