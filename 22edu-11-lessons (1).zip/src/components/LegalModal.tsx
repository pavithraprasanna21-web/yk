import React from 'react';

interface LegalModalProps {
  topic: string | null;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ topic, onClose }) => {
  if (!topic) return null;

  const contentMap: Record<string, { title: string; body: React.ReactNode }> = {
    privacy: {
      title: 'Privacy Policy',
      body: (
        <div className="space-y-4 text-xs sm:text-sm text-[#45464f] leading-relaxed">
          <p>
            At Edu 11 Lessons, we treat your digital privacy with strict standards. We do not sell, rent, or trade your personal email address or reading habits to third parties.
          </p>
          <h4 className="font-bold text-[#000f3f] text-sm">Data We Collect</h4>
          <p>
            When you subscribe to updates or make purchases via our Etsy storefront, we receive basic transactional contact information (such as your designated email address) strictly to deliver your digital download links and periodic educational curriculum updates.
          </p>
          <h4 className="font-bold text-[#000f3f] text-sm">Etsy Transaction Processing</h4>
          <p>
            Payment transactions, credit card data, and billing details are processed securely and independently by Etsy Payments with 256-bit SSL encryption. We never see or store your raw payment details.
          </p>
        </div>
      ),
    },
    terms: {
      title: 'Terms & Conditions',
      body: (
        <div className="space-y-4 text-xs sm:text-sm text-[#45464f] leading-relaxed">
          <p>
            By purchasing and downloading any publication from Edu 11 Lessons, you receive a non-exclusive, non-transferable, single-user personal license for lifetime study.
          </p>
          <h4 className="font-bold text-[#000f3f] text-sm">Permitted Usage</h4>
          <p>
            You are free to load the provided PDF, ePub, and companion files on any personal device you own (e.g., your smartphone, iPad, Kindle, laptop, or desktop) and print physical worksheets for your personal study.
          </p>
          <h4 className="font-bold text-[#000f3f] text-sm">Prohibited Actions</h4>
          <p>
            Re-distributing, reselling, uploading to file-sharing networks, or using our text to train commercial AI datasets without explicit written consent is strictly prohibited.
          </p>
        </div>
      ),
    },
    refund: {
      title: 'Digital Goods Refund Policy',
      body: (
        <div className="space-y-4 text-xs sm:text-sm text-[#45464f] leading-relaxed">
          <p>
            Due to the immediate digital nature of ePub and PDF file downloads, all sales are considered final once the digital files have been downloaded or dispatched.
          </p>
          <h4 className="font-bold text-[#000f3f] text-sm">Our 100% Satisfaction Guarantee</h4>
          <p>
            If you encounter any corrupted file formats, difficulty loading the file onto your Kindle or e-reader, or feel the curriculum significantly diverged from the syllabus preview, contact us within 14 days and our team will provide alternate formats or resolve your concern.
          </p>
        </div>
      ),
    },
  };

  const item = contentMap[topic] || {
    title: 'Legal Information',
    body: <p>Edu 11 Lessons digital publishing policies.</p>,
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#000f3f]/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-[#eaedff] flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-200">
        <div className="px-6 py-4 bg-[#f2f3ff] border-b border-[#eaedff] flex items-center justify-between">
          <h3 className="font-headline text-lg font-bold text-[#000f3f]">{item.title}</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#767680] hover:text-[#000f3f] hover:bg-[#eaedff]"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>
        <div className="p-6 overflow-y-auto">{item.body}</div>
        <div className="p-4 bg-[#f2f3ff] border-t border-[#eaedff] text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#000f3f] text-white text-xs font-semibold rounded-lg hover:bg-[#172554]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
