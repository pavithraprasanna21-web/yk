import React from 'react';
import { Book } from '../types/book';

interface HeroProps {
  onExploreBooks: () => void;
  onOpenEtsy: () => void;
  onSelectBook: (bookId: string) => void;
  books: Book[];
}

export const Hero: React.FC<HeroProps> = ({
  onExploreBooks,
  onOpenEtsy,
  onSelectBook,
  books,
}) => {
  const codingBook = books.find((b) => b.id === 'creative-coding') || books[0];
  const cookeryBook = books.find((b) => b.id === 'mindful-artisan-cookery') || books[1];

  return (
    <section className="relative overflow-hidden bg-[#faf8ff] pt-6 pb-12 sm:pt-10 sm:pb-16 border-b border-[#eaedff]">
      {/* Atmospheric Ambient Glows */}
      <div className="pointer-events-none absolute -top-24 -left-24 w-96 h-96 rounded-full bg-[#ffddb8]/40 blur-3xl opacity-60"></div>
      <div className="pointer-events-none absolute top-1/2 -right-32 w-[32rem] h-[32rem] rounded-full bg-[#adc6ff]/30 blur-3xl opacity-50"></div>

      <div className="max-w-[1200px] mx-auto px-5 lg:px-10 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left: Copy & Primary CTAs */}
          <div className="lg:col-span-7 space-y-5">
            {/* Kicker badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#e2e7ff] shadow-sm">
              <span className="w-2.5 h-2.5 rounded-full bg-[#fea619] animate-pulse"></span>
              <span className="text-xs text-[#000f3f] tracking-wide uppercase font-bold">
                New Spring 2026 Curriculum Released
              </span>
            </div>

            {/* Display Headline */}
            <h1 className="font-headline text-4xl sm:text-5xl lg:text-[54px] text-[#000f3f] tracking-tight leading-[1.12] font-bold">
              Discover Your Next{' '}
              <span className="text-[#855300] underline decoration-[#fea619] decoration-wavy decoration-3">
                Great Read
              </span>
              .
            </h1>

            {/* Subcopy */}
            <p className="text-base sm:text-lg text-[#45464f] max-w-xl leading-relaxed">
              Explore digital books, practical guides, and inspiring resources designed to help you
              learn more, create more, and achieve more. Curated frameworks built for real-world
              impact.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <button
                onClick={onExploreBooks}
                className="inline-flex items-center justify-center text-sm font-semibold bg-[#000f3f] text-white hover:bg-[#172554] px-7 py-3.5 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Explore Books</span>
                <span className="material-symbols-outlined text-[18px] ml-2">arrow_downward</span>
              </button>

              <button
                onClick={onOpenEtsy}
                className="inline-flex items-center justify-center gap-2 text-sm font-semibold bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] px-6 py-3.5 rounded-lg shadow-sm hover:shadow transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0"
              >
                <span className="material-symbols-outlined text-[20px] text-[#684000]">
                  storefront
                </span>
                <span>Visit Our Etsy Shop</span>
                <span className="material-symbols-outlined text-[16px]">open_in_new</span>
              </button>
            </div>

            {/* Subdued Info Notice */}
            <div className="inline-flex items-center gap-2 text-xs text-[#45464f] bg-[#f2f3ff] px-3.5 py-1.5 rounded-md border border-[#c6c5d0]/40">
              <span className="material-symbols-outlined text-[16px] text-[#855300]">info</span>
              <span>Direct instant digital download fulfillment handled securely via Etsy</span>
            </div>

            {/* Trust Badges 3-Column */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white shadow-sm border border-[#eaedff]">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-[#ffddb8] text-[#855300]">
                  <span className="material-symbols-outlined text-[18px]">bolt</span>
                </span>
                <div>
                  <p className="text-xs text-[#131b2e] font-bold">Instant Download</p>
                  <p className="text-[11px] text-[#45464f]">PDF + ePub Bundles</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white shadow-sm border border-[#eaedff]">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-[#dce1ff] text-[#071747]">
                  <span className="material-symbols-outlined text-[18px]">verified_user</span>
                </span>
                <div>
                  <p className="text-xs text-[#131b2e] font-bold">Secure Checkout</p>
                  <p className="text-[11px] text-[#45464f]">Via Etsy Guarantee</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white shadow-sm border border-[#eaedff]">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-[#ffddb8] text-[#855300]">
                  <span className="material-symbols-outlined text-[18px] fill-1">star</span>
                </span>
                <div>
                  <p className="text-xs text-[#131b2e] font-bold">4.9/5 Rating</p>
                  <p className="text-[11px] text-[#45464f]">4,200+ Readers</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: 3D Realistic Book Showcase */}
          <div className="lg:col-span-5 relative flex justify-center items-center py-4 sm:py-6">
            <div className="relative w-full max-w-md h-[400px] sm:h-[440px]">
              {/* Cookery Book (Background Angle) */}
              <button
                onClick={() => onSelectBook(cookeryBook.id)}
                className="absolute -left-2 top-8 w-56 sm:w-64 transform -rotate-6 transition-all duration-300 hover:rotate-0 hover:z-30 hover:scale-105 group text-left focus:outline-none"
                title="Click to view Mindful Artisan Cookery preview"
              >
                <div className="bg-white p-2.5 rounded-xl shadow-xl border border-[#eaedff]">
                  <img
                    alt={cookeryBook.altText}
                    className="w-full h-auto rounded-lg object-cover shadow-sm aspect-[3/4]"
                    src={cookeryBook.coverImage}
                  />
                  <div className="mt-2.5 flex items-center justify-between px-1">
                    <span className="text-[11px] text-[#855300] font-bold uppercase tracking-wider">
                      Cookbook
                    </span>
                    <span className="text-[12px] text-[#45464f] font-semibold">
                      ${cookeryBook.price.toFixed(2)}
                    </span>
                  </div>
                </div>
              </button>

              {/* Creative Coding Book (Foreground Angle) */}
              <button
                onClick={() => onSelectBook(codingBook.id)}
                className="absolute right-0 top-0 w-60 sm:w-72 transform rotate-4 transition-all duration-300 hover:rotate-0 z-20 hover:scale-105 group text-left focus:outline-none"
                title="Click to view Creative Coding preview"
              >
                <div className="bg-white p-3 rounded-xl shadow-2xl border border-[#eaedff]">
                  <div className="relative">
                    <img
                      alt={codingBook.altText}
                      className="w-full h-auto rounded-lg object-cover shadow-sm aspect-[3/4]"
                      src={codingBook.coverImage}
                    />
                    <span className="absolute top-2.5 right-2.5 bg-[#855300] text-white text-[11px] px-2.5 py-1 rounded-full shadow-md font-bold tracking-wide">
                      ★ #1 Tech Seller
                    </span>
                  </div>
                  <div className="mt-3 px-1.5 flex items-center justify-between">
                    <div>
                      <h3 className="font-headline text-[15px] leading-tight text-[#000f3f] font-bold group-hover:text-[#855300] transition-colors">
                        Creative Coding
                      </h3>
                      <p className="text-[11px] text-[#45464f]">Full PDF + Source Files</p>
                    </div>
                    <span className="font-headline text-[16px] text-[#855300] font-bold">
                      ${codingBook.price.toFixed(2)}
                    </span>
                  </div>
                </div>
              </button>

              {/* Floating Micro Metric Floating Badge */}
              <div className="absolute -bottom-2 left-6 sm:left-1/4 z-30 bg-[#000f3f] text-white px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-3 border border-[#172554]">
                <div className="flex -space-x-1.5">
                  <div className="w-6 h-6 rounded-full bg-[#fea619] flex items-center justify-center text-[10px] text-[#000f3f] font-bold">
                    EL
                  </div>
                  <div className="w-6 h-6 rounded-full bg-[#dae2fd] flex items-center justify-center text-[10px] text-[#000f3f] font-bold">
                    99
                  </div>
                  <div className="w-6 h-6 rounded-full bg-[#dce1ff] flex items-center justify-center text-[10px] text-[#071747] font-bold">
                    +
                  </div>
                </div>
                <div className="text-left">
                  <p className="text-[10px] text-[#808dc2] uppercase tracking-wider font-semibold leading-none">
                    Instant PDF &amp; ePub
                  </p>
                  <p className="text-xs text-white font-bold mt-0.5">11 Curated Lessons Each</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
