import React, { useState } from 'react';

export const NewsletterSection: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => {
        setSubscribed(false);
      }, 7000);
    }
  };

  return (
    <section className="py-12 sm:py-16 bg-[#faf8ff]">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-10">
        <div className="bg-white rounded-2xl p-8 md:p-12 shadow-sm text-center max-w-3xl mx-auto space-y-6 border border-[#eaedff]">
          {/* Badge Icon */}
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#ffddb8] text-[#855300] mx-auto shadow-sm">
            <span className="material-symbols-outlined text-[28px]">mark_email_read</span>
          </div>

          <div className="space-y-2">
            <h2 className="font-headline text-2xl sm:text-3xl text-[#000f3f] tracking-tight font-bold">
              Get New Book Updates.
            </h2>
            <p className="text-sm sm:text-base text-[#45464f] max-w-lg mx-auto leading-relaxed">
              Join 15,000+ curious readers. Receive early access notifications for new digital
              releases and exclusive Etsy discount codes straight to your inbox.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-3">
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                required
                className="flex-1 bg-[#f2f3ff] text-[#131b2e] placeholder:text-[#767680] text-sm px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#172554]/20 border border-[#c6c5d0]/50 shadow-sm"
              />
              <button
                type="submit"
                className="text-sm font-semibold bg-[#000f3f] text-white hover:bg-[#172554] px-6 py-3 rounded-lg shadow-sm transition-all whitespace-nowrap active:scale-95"
              >
                Subscribe
              </button>
            </div>

            {subscribed && (
              <div className="p-3 bg-[#e2e7ff] text-[#000f3f] rounded-lg text-xs font-semibold animate-in fade-in duration-200 flex items-center justify-center gap-1.5 border border-[#808dc2]/30">
                <span className="material-symbols-outlined text-[16px] text-[#855300]">check_circle</span>
                <span>Thank you! Check your inbox for your first free reading guide &amp; Etsy promo code.</span>
              </div>
            )}

            <p className="text-[11px] text-[#45464f]">
              Zero spam. Unsubscribe at any time. We respect your digital privacy.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
};
