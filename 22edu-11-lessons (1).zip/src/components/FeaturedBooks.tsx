import React, { useState } from 'react';
import { Book, CategoryId } from '../types/book';

interface FeaturedBooksProps {
  books: Book[];
  onSelectBook: (bookId: string) => void;
  onBuyBook: (book: Book) => void;
  onViewAllCatalog: () => void;
  savedBookIds: string[];
  onToggleSave: (bookId: string) => void;
  activeCategory?: CategoryId;
  onCategoryChange?: (category: CategoryId) => void;
}

export const FeaturedBooks: React.FC<FeaturedBooksProps> = ({
  books,
  onSelectBook,
  onBuyBook,
  onViewAllCatalog,
  savedBookIds,
  onToggleSave,
  activeCategory: propActiveCategory,
  onCategoryChange,
}) => {
  const [internalCategory, setInternalCategory] = useState<CategoryId>('all');
  const activeCategory = propActiveCategory || internalCategory;

  const handleCategoryClick = (cat: CategoryId) => {
    if (onCategoryChange) {
      onCategoryChange(cat);
    } else {
      setInternalCategory(cat);
    }
  };

  const filteredBooks = books.filter((b) => {
    if (activeCategory === 'all') return true;
    return b.category === activeCategory;
  });

  const categoriesList: { id: CategoryId; label: string }[] = [
    { id: 'all', label: 'All Books (24)' },
    { id: 'cookbooks', label: 'Cookbooks & Recipes' },
    { id: 'education', label: 'Education & Study Guides' },
    { id: 'tech', label: 'Technology & Digital Skills' },
    { id: 'language', label: 'Language Learning' },
    { id: 'creative', label: 'Creative Guides' },
    { id: 'lifestyle', label: 'Lifestyle & Hobbies' },
  ];

  return (
    <section id="featured-books" className="py-12 sm:py-16 bg-[#faf8ff] scroll-mt-20">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-10 space-y-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-8 h-1 bg-[#855300] rounded-full"></span>
              <span className="text-xs text-[#855300] font-bold uppercase tracking-wider">
                Curated Publications
              </span>
            </div>
            <h2 className="font-headline text-3xl sm:text-4xl text-[#000f3f] font-bold tracking-tight">
              Featured Books
            </h2>
            <p className="text-sm sm:text-base text-[#45464f] max-w-xl mt-1 leading-relaxed">
              Hand-crafted guides and comprehensive digital books ready to read today. Formatted
              meticulously for tablets, e-readers, and desktops.
            </p>
          </div>

          <button
            onClick={onViewAllCatalog}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm text-[#000f3f] font-bold hover:text-[#855300] transition-colors self-start md:self-auto group"
          >
            <span>View complete Etsy store catalog</span>
            <span className="material-symbols-outlined text-[18px] group-hover:translate-x-1 transition-transform">
              east
            </span>
          </button>
        </div>

        {/* Category Filter Pills (Functional Buttons) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none pt-1">
          {categoriesList.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                type="button"
                className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap transition-all shadow-sm ${
                  isActive
                    ? 'bg-[#000f3f] text-white shadow'
                    : 'bg-[#eaedff] text-[#131b2e] hover:bg-[#e2e7ff] hover:text-[#000f3f]'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* 6-Book Grid matching screenshot */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
          {filteredBooks.map((book) => {
            const isSaved = savedBookIds.includes(book.id);

            return (
              <article
                key={book.id}
                className="flex flex-col bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 border border-[#eaedff] group"
              >
                {/* Book Cover Container */}
                <div className="relative bg-[#eaedff] aspect-[4/3] overflow-hidden flex items-center justify-center p-4">
                  <img
                    alt={book.altText}
                    className="h-full w-auto object-contain transition-transform duration-500 group-hover:scale-105 drop-shadow-md rounded"
                    src={book.coverImage}
                  />

                  {/* Category Pill Tag */}
                  <span
                    className={`absolute top-3 left-3 px-2.5 py-1 rounded-md text-[11px] font-bold tracking-wide backdrop-blur-sm shadow-sm ${
                      book.categoryBadgeClass || 'bg-[#000f3f]/90 text-white'
                    }`}
                  >
                    {book.categoryLabel}
                  </span>

                  {/* Optional Bestseller / Reader Favorite Badge */}
                  {book.tag && (
                    <span className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full bg-[#ffddb8] text-[#855300] text-[11px] font-bold shadow-sm">
                      {book.tag}
                    </span>
                  )}

                  {/* Quick Look Inside Overlay Button */}
                  <div className="absolute inset-0 bg-[#000f3f]/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                    <span className="bg-white/95 text-[#000f3f] text-xs font-bold px-3 py-1.5 rounded-full shadow-lg pointer-events-auto flex items-center gap-1.5 transform translate-y-2 group-hover:translate-y-0 transition-all">
                      <span className="material-symbols-outlined text-[16px]">visibility</span>
                      Look Inside Sample
                    </span>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    {/* Rating row + Save button */}
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-1 text-[#855300]">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <span
                            key={star}
                            className="material-symbols-outlined text-[16px] fill-1"
                          >
                            star
                          </span>
                        ))}
                        <span className="text-xs text-[#45464f] font-medium ml-1">
                          {book.rating.toFixed(2)} ({book.reviewCount} reviews)
                        </span>
                      </div>

                      <button
                        onClick={() => onToggleSave(book.id)}
                        className="text-[#767680] hover:text-[#855300] transition-colors p-1"
                        title={isSaved ? 'Remove from saved' : 'Save for later'}
                      >
                        <span
                          className={`material-symbols-outlined text-[20px] ${
                            isSaved ? 'text-[#855300] fill-1' : ''
                          }`}
                        >
                          {isSaved ? 'bookmark' : 'bookmark_border'}
                        </span>
                      </button>
                    </div>

                    {/* Book Title */}
                    <h3
                      onClick={() => onSelectBook(book.id)}
                      className="font-headline text-lg sm:text-xl text-[#000f3f] font-bold group-hover:text-[#855300] transition-colors cursor-pointer leading-snug"
                    >
                      {book.title}
                    </h3>

                    {/* Description */}
                    <p className="text-xs sm:text-sm text-[#45464f] mt-1.5 line-clamp-2 leading-relaxed">
                      {book.description}
                    </p>

                    {/* Features chips */}
                    <div className="flex flex-wrap items-center gap-2 mt-3 text-[#45464f] text-[11px] font-medium">
                      {book.features.slice(0, 2).map((feat, idx) => (
                        <span
                          key={idx}
                          className="flex items-center gap-1 bg-[#eaedff] px-2 py-0.5 rounded text-[#131b2e]"
                        >
                          <span className="material-symbols-outlined text-[14px] text-[#855300]">
                            {idx === 0 ? 'menu_book' : 'picture_as_pdf'}
                          </span>
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Card Footer: Price & Etsy Button */}
                  <div className="pt-3 border-t border-[#eaedff] flex items-center justify-between">
                    <div>
                      <span className="text-[11px] text-[#45464f] block font-medium">Digital Price</span>
                      <span className="font-headline text-lg text-[#000f3f] font-bold">
                        ${book.price.toFixed(2)}{' '}
                        <span className="text-xs font-normal text-[#45464f]">{book.currency}</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSelectBook(book.id)}
                        className="px-2.5 py-2 rounded-lg bg-[#eaedff] text-[#000f3f] hover:bg-[#e2e7ff] text-xs font-semibold transition-colors"
                        title="Look inside chapter syllabus"
                      >
                        Preview
                      </button>
                      <button
                        onClick={() => onBuyBook(book)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] text-xs font-bold shadow-sm transition-all active:scale-95 whitespace-nowrap"
                      >
                        <span>Buy on Etsy</span>
                        <span className="material-symbols-outlined text-[15px]">open_in_new</span>
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        {filteredBooks.length === 0 && (
          <div className="bg-white rounded-xl p-12 text-center border border-[#eaedff] space-y-3">
            <span className="material-symbols-outlined text-4xl text-[#767680]">menu_book</span>
            <h3 className="font-headline text-lg font-bold text-[#000f3f]">
              No publications in this category yet
            </h3>
            <p className="text-sm text-[#45464f]">
              Try exploring All Books or switch categories above.
            </p>
            <button
              onClick={() => handleCategoryClick('all')}
              className="px-4 py-2 bg-[#000f3f] text-white text-xs font-semibold rounded-lg"
            >
              Reset to All Books
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
