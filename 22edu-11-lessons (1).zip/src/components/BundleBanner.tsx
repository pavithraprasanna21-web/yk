import React from 'react';

interface BundleBannerProps {
  onExplore: () => void;
  onOpenEtsy: () => void;
}

export const BundleBanner: React.FC<BundleBannerProps> = ({ onExplore, onOpenEtsy }) => {
  return (
    <section className="py-8 sm:py-12 bg-[#faf8ff]">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-10">
        <div className="relative overflow-hidden bg-[#000f3f] rounded-2xl text-white p-8 md:p-12 shadow-2xl border border-[#172554]">
          {/* Background Ambient Shapes */}
          <div className="pointer-events-none absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-[#fea619] opacity-25 blur-3xl"></div>
          <div className="pointer-events-none absolute -left-10 -top-10 w-60 h-60 rounded-full bg-[#00265a] opacity-50 blur-2xl"></div>

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-3.5">
              <span className="inline-block px-3 py-1 rounded-full bg-[#855300] text-white text-[11px] font-bold tracking-wider uppercase">
                Limited Digital Bundle
              </span>

              <h2 className="font-headline text-2xl sm:text-3xl lg:text-4xl text-white tracking-tight font-bold">
                Find Your Next Favorite Book.
              </h2>

              <p className="text-sm sm:text-base text-[#dae2fd] max-w-xl leading-relaxed">
                Explore our growing collection of digital books and learning resources. Download
                instantly to your preferred reading device and begin mastering new crafts this
                afternoon.
              </p>
            </div>

            <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3 justify-end">
              <button
                onClick={onExplore}
                className="inline-flex items-center justify-center text-sm font-bold bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] px-6 py-3.5 rounded-lg shadow-md hover:shadow-lg transition-all text-center active:scale-95 whitespace-nowrap"
              >
                Explore Our Collection
              </button>

              <button
                onClick={onOpenEtsy}
                className="inline-flex items-center justify-center gap-2 text-sm font-semibold bg-white/10 hover:bg-white/20 text-white px-6 py-3.5 rounded-lg transition-all text-center active:scale-95 whitespace-nowrap border border-white/20"
              >
                <span>Browse Etsy Best Sellers</span>
                <span className="material-symbols-outlined text-[16px]">open_in_new</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
