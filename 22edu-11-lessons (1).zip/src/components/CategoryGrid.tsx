import React from 'react';
import { CATEGORIES } from '../data/booksData';
import { CategoryId } from '../types/book';

interface CategoryGridProps {
  onSelectCategory: (categoryId: CategoryId) => void;
}

export const CategoryGrid: React.FC<CategoryGridProps> = ({ onSelectCategory }) => {
  return (
    <section className="py-12 sm:py-16 bg-[#f2f3ff] border-y border-[#eaedff]">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-10 space-y-8">
        {/* Header */}
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs text-[#855300] font-bold uppercase tracking-wider">
            Organized Knowledge
          </span>
          <h2 className="font-headline text-3xl sm:text-4xl text-[#000f3f] font-bold tracking-tight">
            Explore by Category
          </h2>
          <p className="text-sm sm:text-base text-[#45464f] leading-relaxed">
            Find exactly what you want to master. Every guide is crafted around 11 progressive,
            actionable lessons.
          </p>
        </div>

        {/* 6 Category Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="group p-6 rounded-xl bg-white shadow-sm hover:shadow-lg transition-all duration-200 hover:-translate-y-1 flex flex-col justify-between h-52 text-left border border-[#eaedff] focus:outline-none"
            >
              <div className="flex items-start justify-between w-full">
                <span
                  className={`w-12 h-12 rounded-lg ${cat.bgClass} flex items-center justify-center ${cat.colorClass} group-hover:scale-110 transition-transform shadow-xs`}
                >
                  <span className="material-symbols-outlined text-[26px]">{cat.icon}</span>
                </span>
                <span className="text-[11px] bg-[#eaedff] px-2.5 py-1 rounded-full text-[#131b2e] font-semibold">
                  {cat.count} Guides
                </span>
              </div>

              <div>
                <h3 className="font-headline text-lg text-[#000f3f] font-bold group-hover:text-[#855300] transition-colors leading-snug">
                  {cat.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#45464f] mt-1 line-clamp-2 leading-relaxed">
                  {cat.subtitle}
                </p>
              </div>

              <span className="text-xs text-[#855300] font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>Explore Category</span>
                <span className="material-symbols-outlined text-[15px]">arrow_forward</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
