import React from 'react';

export const MethodSection: React.FC = () => {
  return (
    <section className="py-12 sm:py-16 bg-[#faf8ff]">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-10 space-y-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs text-[#855300] font-bold uppercase tracking-wider">
            The 11-Lesson Method
          </span>
          <h2 className="font-headline text-3xl sm:text-4xl text-[#000f3f] font-bold tracking-tight">
            Why Choose Edu 11 Lessons?
          </h2>
          <p className="text-sm sm:text-base text-[#45464f] leading-relaxed">
            Designed specifically for adult learners who value density, high visual appeal, and
            zero-fluff learning structures.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Pillar 1 */}
          <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow space-y-3.5 border border-[#eaedff]">
            <div className="w-12 h-12 rounded-xl bg-[#172554] text-white flex items-center justify-center shadow-inner">
              <span className="material-symbols-outlined text-[26px]">devices</span>
            </div>
            <h3 className="font-headline text-lg text-[#000f3f] font-bold leading-tight">
              Digital Learning Resources
            </h3>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              High-resolution PDFs and reflowable ePubs formatted cleanly for iPads, Kindles, Android
              tablets, and laptop screens.
            </p>
          </div>

          {/* Pillar 2 */}
          <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow space-y-3.5 border border-[#eaedff]">
            <div className="w-12 h-12 rounded-xl bg-[#855300] text-white flex items-center justify-center shadow-inner">
              <span className="material-symbols-outlined text-[26px]">task_alt</span>
            </div>
            <h3 className="font-headline text-lg text-[#000f3f] font-bold leading-tight">
              Practical &amp; Easy-to-Follow
            </h3>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              Step-by-step methodologies without filler or unnecessary academic jargon. Learn what
              works immediately.
            </p>
          </div>

          {/* Pillar 3 */}
          <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow space-y-3.5 border border-[#eaedff]">
            <div className="w-12 h-12 rounded-xl bg-[#001232] text-white flex items-center justify-center shadow-inner">
              <span className="material-symbols-outlined text-[26px]">interests</span>
            </div>
            <h3 className="font-headline text-lg text-[#000f3f] font-bold leading-tight">
              For Varied Interests
            </h3>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              Covering modern coding, culinary crafts, academics, and creative hobbies under one
              consistent pedagogical style.
            </p>
          </div>

          {/* Pillar 4 */}
          <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow space-y-3.5 border border-[#eaedff]">
            <div className="w-12 h-12 rounded-xl bg-[#fea619] text-[#684000] flex items-center justify-center shadow-inner">
              <span className="material-symbols-outlined text-[26px]">shopping_bag</span>
            </div>
            <h3 className="font-headline text-lg text-[#000f3f] font-bold leading-tight">
              Convenient Etsy Checkout
            </h3>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              Safe, trusted transaction processing and instantaneous digital delivery via Etsy's
              automated download platform.
            </p>
          </div>
        </div>

        {/* Trust Visual Metric Banner */}
        <div className="bg-[#eaedff] p-6 sm:p-7 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6 border border-[#c6c5d0]/40">
          <div className="flex items-center gap-4">
            <div className="flex items-center justify-center w-14 h-14 rounded-full bg-white text-[#855300] shadow-sm shrink-0">
              <span className="material-symbols-outlined text-[32px]">workspace_premium</span>
            </div>
            <div>
              <h4 className="font-headline text-lg sm:text-xl text-[#000f3f] font-bold">
                Every guide verified by subject experts
              </h4>
              <p className="text-xs sm:text-sm text-[#45464f] mt-0.5">
                Structured with curated exercises, checklists, and printable companions.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-8 shrink-0">
            <div className="text-center md:text-right">
              <p className="font-headline text-2xl sm:text-3xl text-[#000f3f] font-bold">100%</p>
              <p className="text-[11px] text-[#45464f] uppercase tracking-wider font-semibold">
                Instant Digital Access
              </p>
            </div>
            <div className="text-center md:text-right">
              <p className="font-headline text-2xl sm:text-3xl text-[#855300] font-bold">4.9 / 5.0</p>
              <p className="text-[11px] text-[#45464f] uppercase tracking-wider font-semibold">
                Etsy Store Rating
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
