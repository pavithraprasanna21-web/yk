import React from 'react';
import { APP_ASSETS } from '../data/booksData';

export const AboutView: React.FC<{ onExplore: () => void }> = ({ onExplore }) => {
  return (
    <div className="py-10 max-w-[1200px] mx-auto px-5 lg:px-10 space-y-12">
      {/* Hero section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-7 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#eaedff] text-xs font-bold text-[#855300] uppercase tracking-wider">
            Our Story &amp; Pedagogy
          </div>
          <h1 className="font-headline text-3xl sm:text-4xl lg:text-5xl text-[#000f3f] font-bold tracking-tight leading-tight">
            Designed for Learners Who Value Density.
          </h1>
          <p className="text-base sm:text-lg text-[#45464f] leading-relaxed">
            Edu 11 Lessons was founded on an unapologetic standard: adult learners do not have 30
            hours to sift through padded corporate textbooks or 500-word SEO-optimized blog posts.
          </p>
          <p className="text-sm sm:text-base text-[#45464f] leading-relaxed">
            Every digital book in our catalog is engineered to provide exactly 11 sequential,
            high-potency master lessons. By breaking complex topics into 11 discrete frameworks with
            hands-on worksheets, companion source code, or printable kitchen cards, readers achieve
            mastery in days rather than semesters.
          </p>
        </div>

        <div className="lg:col-span-5">
          <div className="p-3 bg-white rounded-2xl shadow-xl border border-[#eaedff]">
            <img
              src={APP_ASSETS.aboutWorkspace}
              alt="Creative workspace"
              className="w-full h-80 object-cover rounded-xl"
            />
            <div className="p-4 bg-[#f2f3ff] rounded-xl mt-3 text-xs text-[#000f3f] font-medium flex items-center justify-between">
              <span>Independent Educational Publishing</span>
              <span className="font-bold text-[#855300]">Est. 2024</span>
            </div>
          </div>
        </div>
      </div>

      {/* The 11-Lesson Architecture Breakdown */}
      <div className="bg-white rounded-2xl p-6 sm:p-10 border border-[#eaedff] shadow-sm space-y-8">
        <div className="max-w-2xl space-y-2">
          <span className="text-xs text-[#855300] font-bold uppercase tracking-wider">
            The Method Behind The Numbers
          </span>
          <h2 className="font-headline text-2xl sm:text-3xl text-[#000f3f] font-bold">
            Why Exactly 11 Lessons?
          </h2>
          <p className="text-sm text-[#45464f] leading-relaxed">
            Our editorial committee analyzed over 200 educational bestsellers across coding,
            culinary arts, and languages. Here is what cognitive science revealed:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-xl bg-[#faf8ff] border border-[#eaedff] space-y-3">
            <span className="w-10 h-10 rounded-lg bg-[#000f3f] text-white flex items-center justify-center font-bold text-sm">
              01
            </span>
            <h3 className="font-headline text-lg font-bold text-[#000f3f]">
              Zero Synthesized Fluff
            </h3>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              Traditional publishers mandate 300+ page lengths to justify physical bookstore shelf
              presence. We design for tablets and e-readers where density and respect for the
              reader's focus are paramount.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-[#faf8ff] border border-[#eaedff] space-y-3">
            <span className="w-10 h-10 rounded-lg bg-[#855300] text-white flex items-center justify-center font-bold text-sm">
              02
            </span>
            <h3 className="font-headline text-lg font-bold text-[#000f3f]">
              Cognitive Chunking
            </h3>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              Eleven is the sweet spot between introductory brevity and deep technical competence.
              Each chapter takes 35 to 60 minutes to read and contains an immediate physical or code
              takeaway.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-[#faf8ff] border border-[#eaedff] space-y-3">
            <span className="w-10 h-10 rounded-lg bg-[#fea619] text-[#684000] flex items-center justify-center font-bold text-sm">
              03
            </span>
            <h3 className="font-headline text-lg font-bold text-[#000f3f]">
              Immediate Proof of Work
            </h3>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              You do not simply read about concepts passively. Every guide includes diagnostic self-tests,
              source repositories, or printable checklist companions to prove skill acquisition.
            </p>
          </div>
        </div>
      </div>

      {/* Editorial Standards & Guarantees */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-[#eaedff] border border-[#c6c5d0]/40 space-y-3">
          <div className="flex items-center gap-2.5 text-[#000f3f]">
            <span className="material-symbols-outlined text-[24px] text-[#855300]">verified</span>
            <h3 className="font-headline text-lg font-bold">100% Human Expert Curation</h3>
          </div>
          <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
            All curriculum outlines are authored and reviewed by veteran practitioners, seasoned chefs,
            polyglots, and senior engineers with verified domain credentials.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#eaedff] border border-[#c6c5d0]/40 space-y-3">
          <div className="flex items-center gap-2.5 text-[#000f3f]">
            <span className="material-symbols-outlined text-[24px] text-[#855300]">storefront</span>
            <h3 className="font-headline text-lg font-bold">Trusted Etsy Marketplace Fulfillment</h3>
          </div>
          <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
            All transactional processing and digital fulfillment is secured through Etsy's proven global
            infrastructure, offering instant automatic digital downloads and buyer protection.
          </p>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="text-center pt-4">
        <button
          onClick={onExplore}
          className="px-8 py-4 bg-[#000f3f] text-white hover:bg-[#172554] font-bold text-sm rounded-xl shadow-md"
        >
          Explore Our Featured Book Catalog
        </button>
      </div>
    </div>
  );
};
