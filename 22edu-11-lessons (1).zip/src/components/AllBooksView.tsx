import React, { useState } from 'react';
import { Book, CategoryId } from '../types/book';

interface AllBooksViewProps {
  books: Book[];
  onSelectBook: (bookId: string) => void;
  onBuyBook: (book: Book) => void;
  savedBookIds: string[];
  onToggleSave: (bookId: string) => void;
  initialCategory?: CategoryId;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const AllBooksView: React.FC<AllBooksViewProps> = ({
  books,
  onSelectBook,
  onBuyBook,
  savedBookIds,
  onToggleSave,
  initialCategory = 'all',
  searchQuery,
  onSearchChange,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>(initialCategory);
  const [sortBy, setSortBy] = useState<'rating' | 'reviews' | 'price-asc' | 'price-desc'>('rating');

  const categories: { id: CategoryId; label: string }[] = [
    { id: 'all', label: 'All Catalog' },
    { id: 'tech', label: 'Technology' },
    { id: 'cookbooks', label: 'Cookbooks' },
    { id: 'education', label: 'Study Guides' },
    { id: 'language', label: 'Language' },
    { id: 'creative', label: 'Creative' },
    { id: 'lifestyle', label: 'Lifestyle' },
  ];

  const filteredBooks = books
    .filter((b) => {
      const matchesCat = selectedCategory === 'all' || b.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery =
        !q ||
        b.title.toLowerCase().includes(q) ||
        b.description.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        b.categoryLabel.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'reviews') return b.reviewCount - a.reviewCount;
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      return 0;
    });

  return (
    <div className="py-10 max-w-[1200px] mx-auto px-5 lg:px-10 space-y-8">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#eaedff] text-xs font-bold text-[#855300] uppercase tracking-wider">
          Complete Digital Vault
        </div>
        <h1 className="font-headline text-3xl sm:text-4xl text-[#000f3f] font-bold tracking-tight">
          All Educational Publications
        </h1>
        <p className="text-sm sm:text-base text-[#45464f] max-w-2xl leading-relaxed">
          Every edition delivers 11 sequential, practical master lessons with printable worksheets,
          ePub digital formats, and lifetime DRM-free access.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#eaedff] shadow-sm space-y-4">
        {/* Search Input */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <span className="material-symbols-outlined absolute left-3 top-3 text-[#767680] text-[20px]">
              search
            </span>
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Filter by title, keywords, or topics..."
              className="w-full bg-[#f2f3ff] text-[#131b2e] placeholder:text-[#767680] text-sm pl-10 pr-4 py-2.5 rounded-xl border border-[#c6c5d0]/60 focus:outline-none focus:ring-2 focus:ring-[#172554]/20"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-[#45464f] font-semibold whitespace-nowrap">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#f2f3ff] text-xs sm:text-sm font-semibold text-[#131b2e] px-3 py-2.5 rounded-xl border border-[#c6c5d0]/60 focus:outline-none"
            >
              <option value="rating">Highest Rated</option>
              <option value="reviews">Most Reviewed</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-[#000f3f] text-white shadow-sm'
                  : 'bg-[#eaedff] text-[#131b2e] hover:bg-[#e2e7ff]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-[#45464f]">
        <span>Showing {filteredBooks.length} educational publications</span>
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="text-[#855300] font-semibold hover:underline"
          >
            Clear search filter
          </button>
        )}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
        {filteredBooks.map((book) => {
          const isSaved = savedBookIds.includes(book.id);

          return (
            <article
              key={book.id}
              className="flex flex-col bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1.5 border border-[#eaedff] group"
            >
              <div className="relative bg-[#eaedff] aspect-[4/3] overflow-hidden flex items-center justify-center p-4">
                <img
                  alt={book.altText}
                  className="h-full w-auto object-contain transition-transform duration-500 group-hover:scale-105 drop-shadow-md rounded"
                  src={book.coverImage}
                />

                <span
                  className={`absolute top-3 left-3 px-2.5 py-1 rounded-md text-[11px] font-bold tracking-wide backdrop-blur-sm shadow-sm ${
                    book.categoryBadgeClass || 'bg-[#000f3f]/90 text-white'
                  }`}
                >
                  {book.categoryLabel}
                </span>

                {book.tag && (
                  <span className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full bg-[#ffddb8] text-[#855300] text-[11px] font-bold shadow-sm">
                    {book.tag}
                  </span>
                )}
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1 text-[#855300]">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <span key={star} className="material-symbols-outlined text-[16px] fill-1">
                          star
                        </span>
                      ))}
                      <span className="text-xs text-[#45464f] font-medium ml-1">
                        {book.rating.toFixed(2)} ({book.reviewCount})
                      </span>
                    </div>

                    <button
                      onClick={() => onToggleSave(book.id)}
                      className="text-[#767680] hover:text-[#855300] transition-colors p-1"
                    >
                      <span
                        className={`material-symbols-outlined text-[20px] ${
                          isSaved ? 'text-[#855300] fill-1' : ''
                        }`}
                      >
                        {isSaved ? 'bookmark' : 'bookmark_border'}
                      </span>
                    </button>
                  </div>

                  <h3
                    onClick={() => onSelectBook(book.id)}
                    className="font-headline text-lg text-[#000f3f] font-bold group-hover:text-[#855300] transition-colors cursor-pointer leading-snug"
                  >
                    {book.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#45464f] mt-1.5 line-clamp-2 leading-relaxed">
                    {book.description}
                  </p>

                  <div className="flex flex-wrap items-center gap-2 mt-3 text-[#45464f] text-[11px] font-medium">
                    {book.features.slice(0, 2).map((feat, idx) => (
                      <span
                        key={idx}
                        className="flex items-center gap-1 bg-[#eaedff] px-2 py-0.5 rounded text-[#131b2e]"
                      >
                        <span className="material-symbols-outlined text-[14px] text-[#855300]">
                          {idx === 0 ? 'menu_book' : 'picture_as_pdf'}
                        </span>
                        {feat}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-[#eaedff] flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-[#45464f] block font-medium">Digital Price</span>
                    <span className="font-headline text-lg text-[#000f3f] font-bold">
                      ${book.price.toFixed(2)}{' '}
                      <span className="text-xs font-normal text-[#45464f]">{book.currency}</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectBook(book.id)}
                      className="px-2.5 py-2 rounded-lg bg-[#eaedff] text-[#000f3f] hover:bg-[#e2e7ff] text-xs font-semibold"
                    >
                      Preview
                    </button>
                    <button
                      onClick={() => onBuyBook(book)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] text-xs font-bold shadow-sm transition-all"
                    >
                      <span>Buy on Etsy</span>
                      <span className="material-symbols-outlined text-[15px]">open_in_new</span>
                    </button>
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>

      {filteredBooks.length === 0 && (
        <div className="bg-white rounded-2xl p-12 text-center border border-[#eaedff] space-y-3">
          <span className="material-symbols-outlined text-4xl text-[#767680]">search_off</span>
          <h3 className="font-headline text-lg font-bold text-[#000f3f]">
            No matching books found
          </h3>
          <p className="text-sm text-[#45464f]">
            No books matched your search query "{searchQuery}". Try searching for another topic or clear filters.
          </p>
          <button
            onClick={() => {
              onSearchChange('');
              setSelectedCategory('all');
            }}
            className="px-4 py-2 bg-[#000f3f] text-white text-xs font-semibold rounded-lg"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
