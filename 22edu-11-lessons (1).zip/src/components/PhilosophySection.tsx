import React from 'react';
import { APP_ASSETS } from '../data/booksData';

export const PhilosophySection: React.FC<{ onLearnMore?: () => void }> = ({ onLearnMore }) => {
  return (
    <section className="py-12 sm:py-16 bg-[#f2f3ff] border-y border-[#eaedff]">
      <div className="max-w-[1200px] mx-auto px-5 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left Column: Image with floating badge */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md">
              <div className="p-3 bg-white rounded-2xl shadow-xl border border-[#eaedff]">
                <img
                  className="w-full h-80 object-cover rounded-xl"
                  alt="Warm modern creative workspace with tablet reading guide"
                  src={APP_ASSETS.aboutWorkspace}
                />
              </div>

              {/* Floating Highlight Card */}
              <div className="absolute -bottom-6 -right-2 sm:-right-4 bg-[#ffddb8] text-[#2a1700] p-4 sm:p-5 rounded-xl shadow-lg max-w-xs border border-[#ffb95f]">
                <p className="font-headline text-[15px] sm:text-[16px] font-bold text-[#855300] leading-snug">
                  11 Chapters. Pure Value.
                </p>
                <p className="text-xs text-[#2a1700] mt-1 leading-relaxed">
                  Engineered to respect your study time without fluff or filler content.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Philosophy Prose */}
          <div className="lg:col-span-7 space-y-5 pt-4 lg:pt-0">
            <div className="flex items-center gap-2">
              <span className="w-8 h-1 bg-[#855300] rounded-full"></span>
              <span className="text-xs text-[#855300] font-bold uppercase tracking-wider">
                Our Philosophy
              </span>
            </div>

            <h2 className="font-headline text-3xl sm:text-4xl text-[#000f3f] tracking-tight font-bold">
              Learning Made Simple.
            </h2>

            <p className="text-base sm:text-lg text-[#45464f] leading-relaxed">
              Edu 11 Lessons was founded on a straightforward observation: most educational
              publications are padded with hundreds of unnecessary pages, while simple blog posts
              lack structured rigor.
            </p>

            <p className="text-sm sm:text-base text-[#45464f] leading-relaxed">
              We bridge that divide. Each publication delivers exactly 11 comprehensive, sequentially
              engineered master lessons accompanied by actionable templates, checklists, and digital
              resource packages. Whether you are stepping into web engineering, mastering artisanal
              kitchen fermentation, or structuring your academic study routine, we give you the tools
              to succeed quickly.
            </p>

            {/* 3 bullet perks */}
            <div className="pt-2 flex flex-wrap gap-5 sm:gap-6">
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[#855300] text-[22px]">
                  auto_stories
                </span>
                <span className="text-xs sm:text-sm text-[#000f3f] font-bold">
                  100% Original Content
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[#855300] text-[22px]">
                  download_done
                </span>
                <span className="text-xs sm:text-sm text-[#000f3f] font-bold">
                  Lifetime File Access
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[#855300] text-[22px]">
                  devices_other
                </span>
                <span className="text-xs sm:text-sm text-[#000f3f] font-bold">
                  Any E-Reader Compatible
                </span>
              </div>
            </div>

            {onLearnMore && (
              <div className="pt-2">
                <button
                  onClick={onLearnMore}
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[#000f3f] hover:text-[#855300] transition-colors"
                >
                  <span>Read our full pedagogical methodology</span>
                  <span className="material-symbols-outlined text-[16px]">east</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
