import React, { useState } from 'react';
import { APP_ASSETS } from '../data/booksData';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenEtsy: () => void;
  onOpenProfile: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  savedCount: number;
  onOpenSaved: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenEtsy,
  onOpenProfile,
  searchQuery,
  onSearchChange,
  savedCount,
  onOpenSaved,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#faf8ff]/90 backdrop-blur-md shadow-[0_1px_8px_rgba(23,37,84,0.06)] border-b border-[#eaedff]">
      <div className="h-20 max-w-[1200px] mx-auto px-5 lg:px-10 flex items-center justify-between gap-4">
        {/* Left: Brand Logo & Wordmark + Nav Links */}
        <div className="flex items-center gap-6 lg:gap-8">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 focus:outline-none text-left group"
          >
            <img
              alt="Edu 11 Lessons Logo"
              className="h-8 w-auto object-contain transition-transform group-hover:scale-105"
              src={APP_ASSETS.logo}
            />
            <span className="font-headline text-xl text-[#000f3f] tracking-tight font-bold whitespace-nowrap">
              Edu 11 Lessons
            </span>
          </button>

          {/* Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 text-sm font-semibold">
            {[
              { id: 'home', label: 'Home' },
              { id: 'all-books', label: 'All Books' },
              { id: 'categories', label: 'Categories' },
              { id: 'about-us', label: 'About Us' },
              { id: 'contact', label: 'Contact' },
            ].map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`transition-colors whitespace-nowrap py-1 ${
                  currentView === link.id
                    ? 'text-[#000f3f] font-bold border-b-2 border-[#fea619]'
                    : 'text-[#45464f] hover:text-[#131b2e]'
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Center: Search Field */}
        <div className="hidden md:flex flex-1 max-w-xs items-center relative">
          <span className="material-symbols-outlined absolute left-3 text-[#767680] text-[20px] pointer-events-none">
            search
          </span>
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => {
              onSearchChange(e.target.value);
              if (currentView !== 'all-books' && e.target.value.trim().length > 0) {
                onNavigate('all-books');
              }
            }}
            placeholder="Search lessons, guides..."
            className="w-full bg-white text-[#131b2e] placeholder:text-[#767680] text-sm pl-10 pr-4 py-2 rounded-lg border border-[#c6c5d0]/60 focus:outline-none focus:ring-2 focus:ring-[#172554]/20 focus:border-[#172554] shadow-[0_1px_3px_rgba(23,37,84,0.04)]"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 text-xs text-gray-400 hover:text-gray-600 p-0.5"
              title="Clear search"
            >
              ✕
            </button>
          )}
        </div>

        {/* Right: Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Explore Books Button */}
          <button
            onClick={() => onNavigate('all-books')}
            className="hidden sm:inline-flex items-center justify-center text-xs font-semibold bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] transition-all px-4 py-2 rounded-lg shadow-sm hover:shadow active:scale-95 whitespace-nowrap"
          >
            Explore Books
          </button>

          {/* Visit Our Etsy Shop */}
          <button
            onClick={onOpenEtsy}
            className="inline-flex items-center gap-1.5 text-xs font-semibold bg-[#eaedff] text-[#131b2e] hover:bg-[#e2e7ff] transition-all px-3 py-2 rounded-full whitespace-nowrap active:scale-95"
            title="Visit official Etsy storefront"
          >
            <span className="material-symbols-outlined text-[16px] text-[#855300]">storefront</span>
            <span className="hidden lg:inline">Visit Our Etsy Shop</span>
            <span className="material-symbols-outlined text-[14px] text-[#767680]">open_in_new</span>
          </button>

          {/* Saved / Library Items Indicator */}
          <button
            onClick={onOpenSaved}
            className="relative flex items-center justify-center w-9 h-9 rounded-full bg-[#f2f3ff] text-[#131b2e] hover:bg-[#e2e7ff] transition-colors"
            title="Saved Guides & Reading List"
          >
            <span className="material-symbols-outlined text-[20px] text-[#172554]">bookmark</span>
            {savedCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#fea619] text-[#684000] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                {savedCount}
              </span>
            )}
          </button>

          {/* Profile Avatar */}
          <button
            onClick={onOpenProfile}
            type="button"
            className="flex items-center rounded-full focus:outline-none focus:ring-2 focus:ring-[#172554]/20 p-0.5 hover:opacity-90 transition-opacity"
            title="My Reading Library & Account"
          >
            <img
              alt="Profile"
              className="w-8 h-8 rounded-full object-cover border border-[#c6c5d0]"
              src={APP_ASSETS.profileAvatar}
            />
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 text-[#131b2e] hover:bg-[#eaedff] rounded-lg focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            <span className="material-symbols-outlined text-[24px]">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-[#eaedff] px-5 py-4 space-y-3 shadow-lg animate-in slide-in-from-top-2 duration-200">
          <div className="relative mb-2">
            <span className="material-symbols-outlined absolute left-3 top-2.5 text-[#767680] text-[18px]">
              search
            </span>
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (currentView !== 'all-books') onNavigate('all-books');
              }}
              placeholder="Search lessons, guides..."
              className="w-full bg-[#f2f3ff] text-[#131b2e] placeholder:text-[#767680] text-sm pl-9 pr-3 py-2 rounded-lg border border-[#c6c5d0]/50"
            />
          </div>
          <div className="flex flex-col space-y-1">
            {[
              { id: 'home', label: 'Home', icon: 'home' },
              { id: 'all-books', label: 'All Books', icon: 'menu_book' },
              { id: 'categories', label: 'Categories', icon: 'category' },
              { id: 'about-us', label: 'About Us', icon: 'info' },
              { id: 'contact', label: 'Contact', icon: 'mail' },
            ].map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                  currentView === link.id
                    ? 'bg-[#eaedff] text-[#000f3f] font-bold'
                    : 'text-[#45464f] hover:bg-[#faf8ff]'
                }`}
              >
                <span className="material-symbols-outlined text-[18px] text-[#855300]">
                  {link.icon}
                </span>
                {link.label}
              </button>
            ))}
          </div>
          <div className="pt-2 border-t border-[#eaedff] flex items-center justify-between gap-2">
            <button
              onClick={() => {
                onNavigate('all-books');
                setMobileMenuOpen(false);
              }}
              className="flex-1 py-2 rounded-lg bg-[#fea619] text-[#684000] text-xs font-semibold text-center"
            >
              Explore Books
            </button>
            <button
              onClick={() => {
                onOpenEtsy();
                setMobileMenuOpen(false);
              }}
              className="flex-1 py-2 rounded-lg bg-[#000f3f] text-white text-xs font-semibold text-center flex items-center justify-center gap-1"
            >
              <span className="material-symbols-outlined text-[14px]">storefront</span>
              Etsy Shop
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
