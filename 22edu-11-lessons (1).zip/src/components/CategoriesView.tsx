import React from 'react';
import { CATEGORIES } from '../data/booksData';
import { Book, CategoryId } from '../types/book';

interface CategoriesViewProps {
  onSelectCategory: (categoryId: CategoryId) => void;
  books: Book[];
  onSelectBook: (bookId: string) => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  onSelectCategory,
  books,
  onSelectBook,
}) => {
  return (
    <div className="py-10 max-w-[1200px] mx-auto px-5 lg:px-10 space-y-10">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#eaedff] text-xs font-bold text-[#855300] uppercase tracking-wider">
          Knowledge Domains
        </div>
        <h1 className="font-headline text-3xl sm:text-4xl text-[#000f3f] font-bold tracking-tight">
          Explore Book Categories
        </h1>
        <p className="text-sm sm:text-base text-[#45464f] max-w-2xl leading-relaxed">
          Each curriculum category adheres to our rigorous 11-Lesson framework: dense, structured,
          practical, and accompanied by companion assets.
        </p>
      </div>

      {/* Categories Detailed Cards */}
      <div className="space-y-8">
        {CATEGORIES.map((cat) => {
          const categoryBooks = books.filter((b) => b.category === cat.id);

          return (
            <div
              key={cat.id}
              className="bg-white rounded-2xl p-6 sm:p-8 border border-[#eaedff] shadow-sm space-y-6"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <span
                    className={`w-14 h-14 rounded-xl ${cat.bgClass} flex items-center justify-center ${cat.colorClass} shadow-xs shrink-0`}
                  >
                    <span className="material-symbols-outlined text-[32px]">{cat.icon}</span>
                  </span>
                  <div>
                    <h2 className="font-headline text-xl sm:text-2xl text-[#000f3f] font-bold">
                      {cat.title}
                    </h2>
                    <p className="text-xs sm:text-sm text-[#45464f] mt-0.5">{cat.subtitle}</p>
                  </div>
                </div>

                <button
                  onClick={() => onSelectCategory(cat.id)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#000f3f] text-white hover:bg-[#172554] text-xs font-semibold self-start sm:self-auto transition-colors"
                >
                  <span>View all {cat.count} Guides</span>
                  <span className="material-symbols-outlined text-[16px]">east</span>
                </button>
              </div>

              <p className="text-sm text-[#45464f] leading-relaxed max-w-3xl">
                {cat.description}
              </p>

              {/* Featured Book Thumbnails under category */}
              {categoryBooks.length > 0 && (
                <div className="pt-2 border-t border-[#eaedff]">
                  <p className="text-xs font-bold text-[#000f3f] uppercase tracking-wider mb-3">
                    Featured In This Category:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {categoryBooks.map((b) => (
                      <div
                        key={b.id}
                        onClick={() => onSelectBook(b.id)}
                        className="p-3 rounded-xl bg-[#faf8ff] border border-[#eaedff] flex items-center gap-3 cursor-pointer hover:bg-[#f2f3ff] transition-all group"
                      >
                        <img
                          src={b.coverImage}
                          alt={b.altText}
                          className="w-12 h-16 object-contain rounded bg-white shadow-xs p-0.5 shrink-0"
                        />
                        <div className="min-w-0">
                          <h4 className="font-headline text-xs font-bold text-[#000f3f] group-hover:text-[#855300] transition-colors truncate">
                            {b.title}
                          </h4>
                          <p className="text-[11px] text-[#45464f]">By {b.author}</p>
                          <span className="text-[11px] font-bold text-[#855300]">
                            ${b.price.toFixed(2)} USD
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
