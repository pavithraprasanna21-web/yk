import React, { useState } from 'react';
import { Book } from '../types/book';

interface EtsyCheckoutModalProps {
  book: Book | null;
  onClose: () => void;
  onSuccessDownload: (book: Book) => void;
}

export const EtsyCheckoutModal: React.FC<EtsyCheckoutModalProps> = ({
  book,
  onClose,
  onSuccessDownload,
}) => {
  const [promoCode, setPromoCode] = useState('SPRING2026');
  const [discountApplied, setDiscountApplied] = useState(true);
  const [email, setEmail] = useState('pavithraprasanna21@gmail.com');
  const [formatChoice, setFormatChoice] = useState<'bundle' | 'pdf' | 'epub'>('bundle');
  const [isProcessing, setIsProcessing] = useState(false);
  const [completed, setCompleted] = useState(false);

  if (!book) return null;

  const basePrice = book.price || 14.99;
  const discountAmount = discountApplied ? 3.0 : 0;
  const finalPrice = Math.max(0, basePrice - discountAmount);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim().toUpperCase() === 'SPRING2026' || promoCode.trim().toUpperCase() === 'EDU11') {
      setDiscountApplied(true);
    } else {
      alert('Promo code not recognized. Try SPRING2026 for $3.00 off!');
      setDiscountApplied(false);
    }
  };

  const handleCompleteOrder = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setCompleted(true);
      onSuccessDownload(book);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#000f3f]/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-[#eaedff] flex flex-col animate-in zoom-in-95 duration-200">
        {/* Header with Etsy Branding */}
        <div className="px-6 py-4 bg-[#f2f3ff] border-b border-[#eaedff] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-[#fea619] text-[#684000]">
              <span className="material-symbols-outlined text-[18px]">storefront</span>
            </span>
            <div>
              <p className="text-xs font-bold text-[#000f3f]">Etsy Verified Digital Storefront</p>
              <p className="text-[11px] text-[#45464f]">Edu 11 Lessons Official Shop</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#767680] hover:text-[#000f3f] hover:bg-[#eaedff] transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {!completed ? (
            <>
              {/* Product summary card */}
              <div className="p-4 rounded-xl bg-[#faf8ff] border border-[#eaedff] flex gap-4 items-center">
                <img
                  src={book.coverImage}
                  alt={book.altText}
                  className="w-16 h-20 object-contain rounded shadow-sm bg-white p-1"
                />
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold uppercase text-[#855300] tracking-wider">
                    {book.categoryLabel}
                  </span>
                  <h4 className="font-headline text-sm sm:text-base font-bold text-[#000f3f] truncate">
                    {book.title}
                  </h4>
                  <p className="text-xs text-[#45464f]">11 Comprehensive Lessons · Instant ePub + PDF</p>
                  <p className="text-xs font-bold text-[#000f3f] mt-1">
                    ${basePrice.toFixed(2)} USD
                  </p>
                </div>
              </div>

              {/* Format package selection */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#000f3f]">Select Download Delivery Package:</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormatChoice('bundle')}
                    className={`p-2.5 rounded-lg text-left border text-xs transition-all ${
                      formatChoice === 'bundle'
                        ? 'border-[#000f3f] bg-[#e2e7ff] text-[#000f3f] font-bold'
                        : 'border-[#eaedff] bg-white text-[#45464f]'
                    }`}
                  >
                    <p className="font-bold">Full Bundle</p>
                    <p className="text-[10px] opacity-80">PDF + ePub + Assets</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormatChoice('pdf')}
                    className={`p-2.5 rounded-lg text-left border text-xs transition-all ${
                      formatChoice === 'pdf'
                        ? 'border-[#000f3f] bg-[#e2e7ff] text-[#000f3f] font-bold'
                        : 'border-[#eaedff] bg-white text-[#45464f]'
                    }`}
                  >
                    <p className="font-bold">PDF Only</p>
                    <p className="text-[10px] opacity-80">For iPad &amp; Print</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormatChoice('epub')}
                    className={`p-2.5 rounded-lg text-left border text-xs transition-all ${
                      formatChoice === 'epub'
                        ? 'border-[#000f3f] bg-[#e2e7ff] text-[#000f3f] font-bold'
                        : 'border-[#eaedff] bg-white text-[#45464f]'
                    }`}
                  >
                    <p className="font-bold">ePub Only</p>
                    <p className="text-[10px] opacity-80">Kindle &amp; Kobo</p>
                  </button>
                </div>
              </div>

              {/* Delivery Email */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#000f3f]">Delivery Email Address:</label>
                <div className="relative">
                  <span className="material-symbols-outlined absolute left-3 top-2.5 text-[#767680] text-[18px]">
                    mail
                  </span>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="you@domain.com"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-[#faf8ff] rounded-lg border border-[#c6c5d0] focus:ring-2 focus:ring-[#172554]/20 focus:outline-none"
                  />
                </div>
                <p className="text-[11px] text-[#45464f]">
                  Instant download links and receipt will be delivered here automatically.
                </p>
              </div>

              {/* Promo code */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <input
                  type="text"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  placeholder="Promo Code (SPRING2026)"
                  className="flex-1 px-3 py-2 text-xs bg-[#faf8ff] rounded-lg border border-[#c6c5d0] uppercase font-mono"
                />
                <button
                  type="submit"
                  className="px-3 py-2 text-xs font-bold bg-[#eaedff] text-[#000f3f] hover:bg-[#e2e7ff] rounded-lg"
                >
                  Apply Code
                </button>
              </form>

              {/* Price Calculation */}
              <div className="p-3 bg-[#f2f3ff] rounded-xl space-y-1.5 text-xs">
                <div className="flex justify-between text-[#45464f]">
                  <span>Item Subtotal:</span>
                  <span>${basePrice.toFixed(2)}</span>
                </div>
                {discountApplied && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Spring Reader Discount (SPRING2026):</span>
                    <span>-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="border-t border-[#eaedff] pt-1.5 flex justify-between text-sm font-bold text-[#000f3f]">
                  <span>Total Due Today:</span>
                  <span>${finalPrice.toFixed(2)} USD</span>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={handleCompleteOrder}
                  disabled={isProcessing}
                  className="w-full py-3.5 px-4 rounded-xl bg-[#fea619] text-[#684000] hover:bg-[#ffb95f] hover:text-[#2a1700] font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <span className="animate-spin text-lg">◌</span>
                      <span>Processing Etsy Guarantee Transaction...</span>
                    </>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-[18px]">verified</span>
                      <span>Instant Download &amp; Pay ${finalPrice.toFixed(2)}</span>
                    </>
                  )}
                </button>

                <a
                  href="https://etsy.com/shop/Edu11Lessons"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 px-3 rounded-xl bg-[#000f3f] text-white hover:bg-[#172554] font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>Open directly in Etsy App / Browser</span>
                  <span className="material-symbols-outlined text-[14px]">open_in_new</span>
                </a>
              </div>
            </>
          ) : (
            /* Order Success View */
            <div className="text-center py-6 space-y-4 animate-in fade-in">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
                <span className="material-symbols-outlined text-3xl">check_circle</span>
              </div>

              <div>
                <h3 className="font-headline text-xl font-bold text-[#000f3f]">
                  Order Confirmed &amp; Dispatched!
                </h3>
                <p className="text-xs sm:text-sm text-[#45464f] mt-1 max-w-sm mx-auto">
                  Your digital book bundle has been generated and sent to <span className="font-semibold text-[#000f3f]">{email}</span>. It is also now permanently accessible in your My Library tab.
                </p>
              </div>

              <div className="p-4 bg-[#f2f3ff] rounded-xl text-left border border-[#eaedff] space-y-2 text-xs">
                <div className="flex justify-between font-semibold text-[#000f3f]">
                  <span>Item:</span>
                  <span>{book.title}</span>
                </div>
                <div className="flex justify-between text-[#45464f]">
                  <span>Format:</span>
                  <span>{formatChoice === 'bundle' ? 'PDF + ePub + Worksheets' : formatChoice.toUpperCase()}</span>
                </div>
                <div className="flex justify-between text-[#45464f]">
                  <span>License:</span>
                  <span>Single-User Personal DRM-Free Lifetime</span>
                </div>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    // Trigger sample download
                    const sampleContent = `# ${book.title}\nBy ${book.author}\n\nEdu 11 Lessons Official Verified Download\n\n${book.fullDescription}\n\n${book.sampleChapterText || ''}`;
                    const blob = new Blob([sampleContent], { type: 'text/markdown;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', `${book.id}-full-edition.md`);
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                    onClose();
                  }}
                  className="w-full py-3 bg-[#000f3f] text-white hover:bg-[#172554] font-bold text-xs rounded-xl shadow flex items-center justify-center gap-1.5"
                >
                  <span className="material-symbols-outlined text-[16px]">download</span>
                  <span>Save Files Now (.ZIP / .MD)</span>
                </button>

                <button
                  onClick={onClose}
                  className="w-full py-2.5 text-xs font-semibold text-[#45464f] hover:bg-[#eaedff] rounded-xl"
                >
                  Return to Storefront
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
