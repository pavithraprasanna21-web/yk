/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FeaturedBooks } from './components/FeaturedBooks';
import { CategoryGrid } from './components/CategoryGrid';
import { MethodSection } from './components/MethodSection';
import { BundleBanner } from './components/BundleBanner';
import { PhilosophySection } from './components/PhilosophySection';
import { NewsletterSection } from './components/NewsletterSection';
import { Footer } from './components/Footer';
import { BookDetailModal } from './components/BookDetailModal';
import { EtsyCheckoutModal } from './components/EtsyCheckoutModal';
import { ProfileModal } from './components/ProfileModal';
import { LegalModal } from './components/LegalModal';
import { AllBooksView } from './components/AllBooksView';
import { CategoriesView } from './components/CategoriesView';
import { AboutView } from './components/AboutView';
import { ContactView } from './components/ContactView';
import { ALL_CATALOG_BOOKS, BOOKS_DATA } from './data/booksData';
import { Book, CategoryId } from './types/book';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [activeCategory, setActiveCategory] = useState<CategoryId>('all');
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null);
  const [checkoutBook, setCheckoutBook] = useState<Book | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [legalTopic, setLegalTopic] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // User Library & Saved state
  const [savedBookIds, setSavedBookIds] = useState<string[]>(['creative-coding', 'mindful-artisan-cookery']);
  const [purchasedBookIds, setPurchasedBookIds] = useState<string[]>(['creative-coding']);

  const toggleSaveBook = (bookId: string) => {
    setSavedBookIds((prev) =>
      prev.includes(bookId) ? prev.filter((id) => id !== bookId) : [...prev, bookId]
    );
  };

  const handleOrderSuccess = (book: Book) => {
    if (!purchasedBookIds.includes(book.id)) {
      setPurchasedBookIds((prev) => [...prev, book.id]);
    }
  };

  const selectedBook = ALL_CATALOG_BOOKS.find((b) => b.id === selectedBookId) || null;
  const savedBooks = ALL_CATALOG_BOOKS.filter((b) => savedBookIds.includes(b.id));
  const purchasedBooks = ALL_CATALOG_BOOKS.filter((b) => purchasedBookIds.includes(b.id));

  // Navigation handlers
  const handleNavigate = (view: string) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCategory = (categoryId: CategoryId) => {
    setActiveCategory(categoryId);
    setCurrentView('all-books');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleExploreBooksFromHero = () => {
    const featuredElem = document.getElementById('featured-books');
    if (currentView === 'home' && featuredElem) {
      featuredElem.scrollIntoView({ behavior: 'smooth' });
    } else {
      setCurrentView('all-books');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleOpenEtsyStore = () => {
    // Open Etsy checkout for the flagship bestseller book
    const flagship = ALL_CATALOG_BOOKS.find((b) => b.id === 'creative-coding') || ALL_CATALOG_BOOKS[0];
    setCheckoutBook(flagship);
  };

  return (
    <div className="min-h-screen bg-[#faf8ff] text-[#131b2e] flex flex-col font-body selection:bg-[#fea619]/30">
      {/* Top Fixed Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenEtsy={handleOpenEtsyStore}
        onOpenProfile={() => setIsProfileOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        savedCount={savedBookIds.length}
        onOpenSaved={() => setIsProfileOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pt-20">
        {currentView === 'home' && (
          <div className="flex flex-col w-full">
            {/* HERO SECTION with 3D Books Showcase */}
            <Hero
              onExploreBooks={handleExploreBooksFromHero}
              onOpenEtsy={handleOpenEtsyStore}
              onSelectBook={(id) => setSelectedBookId(id)}
              books={BOOKS_DATA}
            />

            {/* FEATURED BOOKS CATALOG SECTION with category pills */}
            <FeaturedBooks
              books={BOOKS_DATA}
              onSelectBook={(id) => setSelectedBookId(id)}
              onBuyBook={(book) => setCheckoutBook(book)}
              onViewAllCatalog={() => handleNavigate('all-books')}
              savedBookIds={savedBookIds}
              onToggleSave={toggleSaveBook}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
            />

            {/* BROWSE BY CATEGORY SECTION */}
            <CategoryGrid onSelectCategory={handleSelectCategory} />

            {/* WHY CHOOSE EDU 11 LESSONS? (The 11-Lesson Method) */}
            <MethodSection />

            {/* SPECIAL PROMOTION / FEATURED HERO BANNER */}
            <BundleBanner
              onExplore={() => handleNavigate('all-books')}
              onOpenEtsy={handleOpenEtsyStore}
            />

            {/* ABOUT US PHILOSOPHY SECTION */}
            <PhilosophySection onLearnMore={() => handleNavigate('about-us')} />

            {/* NEWSLETTER / UPDATES SECTION */}
            <NewsletterSection />
          </div>
        )}

        {currentView === 'all-books' && (
          <AllBooksView
            books={ALL_CATALOG_BOOKS}
            onSelectBook={(id) => setSelectedBookId(id)}
            onBuyBook={(book) => setCheckoutBook(book)}
            savedBookIds={savedBookIds}
            onToggleSave={toggleSaveBook}
            initialCategory={activeCategory}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />
        )}

        {currentView === 'categories' && (
          <CategoriesView
            onSelectCategory={handleSelectCategory}
            books={ALL_CATALOG_BOOKS}
            onSelectBook={(id) => setSelectedBookId(id)}
          />
        )}

        {currentView === 'about-us' && (
          <AboutView onExplore={() => handleNavigate('all-books')} />
        )}

        {currentView === 'contact' && (
          <ContactView onOpenEtsy={handleOpenEtsyStore} />
        )}
      </main>

      {/* Global Footer */}
      <Footer
        onNavigate={handleNavigate}
        onSelectCategory={handleSelectCategory}
        onOpenEtsy={handleOpenEtsyStore}
        onOpenLegal={(topic) => setLegalTopic(topic)}
      />

      {/* Modals */}
      <BookDetailModal
        book={selectedBook}
        onClose={() => setSelectedBookId(null)}
        onBuy={(book) => {
          setSelectedBookId(null);
          setCheckoutBook(book);
        }}
        isSaved={selectedBook ? savedBookIds.includes(selectedBook.id) : false}
        onToggleSave={toggleSaveBook}
      />

      <EtsyCheckoutModal
        book={checkoutBook}
        onClose={() => setCheckoutBook(null)}
        onSuccessDownload={handleOrderSuccess}
      />

      {isProfileOpen && (
        <ProfileModal
          onClose={() => setIsProfileOpen(false)}
          savedBooks={savedBooks}
          purchasedBooks={purchasedBooks}
          onOpenBook={(id) => {
            setIsProfileOpen(false);
            setSelectedBookId(id);
          }}
          onRemoveSaved={toggleSaveBook}
          onOpenEtsyCheckout={(book) => {
            setIsProfileOpen(false);
            setCheckoutBook(book);
          }}
        />
      )}

      <LegalModal topic={legalTopic} onClose={() => setLegalTopic(null)} />
    </div>
  );
}
