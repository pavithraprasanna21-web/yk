export type CategoryId = 
  | 'all'
  | 'cookbooks'
  | 'education'
  | 'tech'
  | 'language'
  | 'creative'
  | 'lifestyle';

export interface Lesson {
  number: number;
  title: string;
  duration: string;
  summary: string;
  keyTakeaway: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  category: CategoryId;
  categoryLabel: string;
  categoryBadgeClass?: string;
  tag?: string;
  coverImage: string;
  altText: string;
  rating: number;
  reviewCount: number;
  description: string;
  fullDescription: string;
  price: number;
  currency: string;
  features: string[];
  formats: ('PDF' | 'ePub' | 'Audio' | 'Worksheets' | 'Code Files')[];
  pageCount: number;
  lessonsCount: number;
  lessons: Lesson[];
  sampleChapterText?: string;
  etsyUrl?: string;
  isBestseller?: boolean;
  isReaderFavorite?: boolean;
}

export interface CategoryInfo {
  id: CategoryId;
  title: string;
  subtitle: string;
  icon: string;
  count: number;
  bgClass: string;
  colorClass: string;
  description: string;
}
